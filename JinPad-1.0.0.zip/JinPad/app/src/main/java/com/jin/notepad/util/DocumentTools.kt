package com.jin.notepad.util

import org.json.JSONArray
import org.json.JSONObject
import java.io.StringReader
import java.io.StringWriter
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.TransformerFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult
import org.xml.sax.InputSource

object DocumentTools {
    fun format(title: String, text: String): String {
        return when (title.substringAfterLast('.', "").lowercase()) {
            "json" -> formatJson(text)
            "xml" -> formatXml(text)
            else -> text
        }
    }

    private fun formatJson(text: String): String {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return text
        return when {
            trimmed.startsWith("{") -> JSONObject(trimmed).toString(2)
            trimmed.startsWith("[") -> JSONArray(trimmed).toString(2)
            else -> error("JSON must start with { or [")
        }
    }

    private fun formatXml(text: String): String {
        val factory = DocumentBuilderFactory.newInstance().apply {
            isNamespaceAware = true
            runCatching { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
        }
        val document = factory.newDocumentBuilder().parse(InputSource(StringReader(text)))
        val transformer = TransformerFactory.newInstance().newTransformer().apply {
            setOutputProperty(OutputKeys.INDENT, "yes")
            setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2")
            setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no")
        }
        return StringWriter().also {
            transformer.transform(DOMSource(document), StreamResult(it))
        }.toString().trimEnd()
    }
}
