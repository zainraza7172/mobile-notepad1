package com.jin.notepad

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.key.*
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.WindowCompat
import com.jin.notepad.model.EditorTab
import com.jin.notepad.model.LineEnding
import com.jin.notepad.model.TextEncoding
import com.jin.notepad.model.ThemeMode
import com.jin.notepad.ui.EditorViewModel
import com.jin.notepad.ui.JinPadTheme
import com.jin.notepad.util.CodeVisualTransformation
import com.jin.notepad.util.FileUtils
import com.jin.notepad.util.SyntaxColors
import kotlinx.coroutines.delay
import java.text.DateFormat
import java.util.Date

class MainActivity : ComponentActivity() {
    private val editorViewModel: EditorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        editorViewModel.handleExternalIntent(this, intent)
        setContent {
            val state = editorViewModel.uiState
            JinPadTheme(state.settings.themeMode) {
                JinPadApp(editorViewModel)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        editorViewModel.handleExternalIntent(this, intent)
    }
}

private enum class DesktopMenu { FILE, EDIT, FORMAT, VIEW, HELP }

@Composable
@Suppress("DEPRECATION")
private fun JinPadApp(viewModel: EditorViewModel) {
    val state = viewModel.uiState
    val context = LocalContext.current
    val density = LocalDensity.current
    val clipboard = LocalClipboardManager.current
    val imeVisible = WindowInsets.ime.getBottom(density) > 0
    var openMenu by remember { mutableStateOf<DesktopMenu?>(null) }
    var pendingClose by remember { mutableStateOf<EditorTab?>(null) }
    var closeAfterSaveTabId by remember { mutableStateOf<String?>(null) }
    var aboutVisible by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }
    val focusRequester = remember { FocusRequester() }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { viewModel.openUri(context, it) }
    }
    val saveAsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        uri?.let { selectedUri ->
            val closeId = closeAfterSaveTabId
            viewModel.saveAs(context, selectedUri) {
                if (closeId != null) viewModel.closeTab(closeId)
                closeAfterSaveTabId = null
            }
        } ?: run { closeAfterSaveTabId = null }
    }

    fun save() {
        val tab = state.activeTab ?: return
        if (tab.uri == null) saveAsLauncher.launch(suggestedSaveName(tab.title))
        else viewModel.saveCurrent(context)
    }

    fun requestClose(tab: EditorTab) {
        if (tab.isDirty) pendingClose = tab else viewModel.closeTab(tab.id)
    }

    fun shareCurrent() {
        val tab = state.activeTab ?: return
        val intent = if (tab.uri != null) {
            Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_STREAM, Uri.parse(tab.uri))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } else {
            Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, tab.value.text)
            }
        }
        context.startActivity(Intent.createChooser(intent, "Share from JinPad"))
    }

    fun copySelection() {
        val tab = state.activeTab ?: return
        val sel = tab.value.selection
        if (!sel.collapsed) clipboard.setText(AnnotatedString(tab.value.text.substring(sel.min, sel.max)))
    }
    fun cutSelection() {
        val tab = state.activeTab ?: return
        if (tab.value.selection.collapsed) return
        copySelection()
        viewModel.insertText("")
    }
    fun pasteClipboard() {
        clipboard.getText()?.text?.let(viewModel::insertText)
    }

    LaunchedEffect(state.message) {
        val message = state.message ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(message)
        viewModel.clearMessage()
    }

    LaunchedEffect(state.activeTabId) {
        delay(40)
        runCatching { focusRequester.requestFocus() }
    }

    val shortcutModifier = Modifier.onPreviewKeyEvent { event ->
        if (event.type != KeyEventType.KeyDown || !event.isCtrlPressed) return@onPreviewKeyEvent false
        when (event.key) {
            Key.N -> { if (event.isShiftPressed) viewModel.showNewFile(true) else viewModel.newTab(); true }
            Key.O -> { openLauncher.launch(arrayOf("*/*")); true }
            Key.S -> {
                if (event.isShiftPressed) saveAsLauncher.launch(suggestedSaveName(state.activeTab?.title ?: "Untitled.txt"))
                else save()
                true
            }
            Key.F -> { viewModel.setFindVisible(true); true }
            Key.H -> { viewModel.setFindVisible(true, replace = true); true }
            Key.G -> { viewModel.showGoToLine(true); true }
            Key.Z -> { viewModel.undo(); true }
            Key.Y -> { viewModel.redo(); true }
            Key.A -> { viewModel.selectAll(); true }
            Key.W -> { state.activeTab?.let(::requestClose); true }
            Key.D -> { viewModel.duplicateLine(); true }
            Key.Tab -> { viewModel.selectRelativeTab(if (event.isShiftPressed) -1 else 1); true }
            Key.Equals -> { viewModel.setFontSize(state.settings.fontSizeSp + 1f); true }
            Key.Minus -> { viewModel.setFontSize(state.settings.fontSizeSp - 1f); true }
            Key.Zero -> { viewModel.setFontSize(17f); true }
            else -> false
        }
    }

    Scaffold(
        modifier = shortcutModifier.fillMaxSize().imePadding(),
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            JinPadTopBar(
                tabs = state.tabs,
                activeTabId = state.activeTabId,
                activeTab = state.activeTab,
                openMenu = openMenu,
                canUndo = state.activeTab?.undoStack?.isNotEmpty() == true,
                canRedo = state.activeTab?.redoStack?.isNotEmpty() == true,
                wordWrap = state.settings.wordWrap,
                lineNumbers = state.settings.lineNumbers,
                statusBar = state.settings.showStatusBar,
                syntaxHighlighting = state.settings.syntaxHighlighting,
                markdownPreview = state.markdownPreviewVisible,
                onMenuChange = { openMenu = it },
                onSelect = viewModel::selectTab,
                onClose = { id -> state.tabs.firstOrNull { it.id == id }?.let(::requestClose) },
                onCloseOthers = viewModel::closeOtherTabs,
                onCloseAllClean = viewModel::closeAllCleanTabs,
                onMoveTab = viewModel::moveTab,
                onNew = { viewModel.newTab() },
                onNewType = { viewModel.showNewFile(true) },
                onOpen = { openLauncher.launch(arrayOf("*/*")) },
                onSave = ::save,
                onSaveAs = { saveAsLauncher.launch(suggestedSaveName(state.activeTab?.title ?: "Untitled.txt")) },
                onRecent = { viewModel.showRecent(true) },
                onFileInfo = { viewModel.showFileInfo(true) },
                onShare = ::shareCurrent,
                onUndo = viewModel::undo,
                onRedo = viewModel::redo,
                onCut = ::cutSelection,
                onCopy = ::copySelection,
                onPaste = ::pasteClipboard,
                onFind = { viewModel.setFindVisible(true) },
                onReplace = { viewModel.setFindVisible(true, replace = true) },
                onGoToLine = { viewModel.showGoToLine(true) },
                onDuplicateLine = viewModel::duplicateLine,
                onIndent = viewModel::indentSelection,
                onUnindent = viewModel::unindentSelection,
                onSelectAll = viewModel::selectAll,
                onFormat = viewModel::formatDocument,
                onEncoding = viewModel::setCurrentEncoding,
                onLineEnding = viewModel::setCurrentLineEnding,
                onWordWrap = viewModel::setWordWrap,
                onLineNumbers = viewModel::setLineNumbers,
                onStatusBar = viewModel::setShowStatusBar,
                onSyntaxHighlighting = viewModel::setSyntaxHighlighting,
                onMarkdownPreview = viewModel::setMarkdownPreviewVisible,
                onZoomOut = { viewModel.setFontSize(state.settings.fontSizeSp - 1f) },
                onZoomIn = { viewModel.setFontSize(state.settings.fontSizeSp + 1f) },
                onZoomReset = { viewModel.setFontSize(17f) },
                onSettings = { viewModel.showSettings(true) },
                onAbout = { aboutVisible = true }
            )
        },
        bottomBar = {
            Column(Modifier.fillMaxWidth().navigationBarsPadding()) {
                if (imeVisible && state.settings.showQuickToolbar) {
                    CodeKeyboardToolbar(
                        tabWidth = state.settings.tabWidth,
                        onInsert = viewModel::insertText,
                        onIndent = viewModel::indentSelection,
                        onUnindent = viewModel::unindentSelection,
                        onDuplicate = viewModel::duplicateLine,
                        onSave = ::save
                    )
                } else if (!imeVisible && state.settings.showQuickToolbar) {
                    QuickToolbar(
                        canUndo = state.activeTab?.undoStack?.isNotEmpty() == true,
                        canRedo = state.activeTab?.redoStack?.isNotEmpty() == true,
                        onUndo = viewModel::undo,
                        onRedo = viewModel::redo,
                        onFind = { viewModel.setFindVisible(true) },
                        onSave = ::save,
                        onGoToLine = { viewModel.showGoToLine(true) },
                        onZoomOut = { viewModel.setFontSize(state.settings.fontSizeSp - 1f) },
                        onZoomIn = { viewModel.setFontSize(state.settings.fontSizeSp + 1f) }
                    )
                }
                if (!imeVisible && state.settings.showStatusBar) {
                    StatusBar(state.activeTab, state.settings.fontSizeSp)
                }
            }
        }
    ) { innerPadding ->
        Column(Modifier.fillMaxSize().padding(innerPadding)) {
            if (state.findVisible) {
                FindReplaceBar(
                    query = state.findQuery,
                    replace = state.replaceQuery,
                    replaceVisible = state.replaceVisible,
                    matchCase = state.matchCase,
                    wholeWord = state.wholeWord,
                    regex = state.regexSearch,
                    onQuery = viewModel::setFindQuery,
                    onReplace = viewModel::setReplaceQuery,
                    onMatchCase = viewModel::setMatchCase,
                    onWholeWord = viewModel::setWholeWord,
                    onRegex = viewModel::setRegexSearch,
                    onPrev = { viewModel.findNext(backwards = true) },
                    onNext = { viewModel.findNext() },
                    onReplaceOne = viewModel::replaceCurrent,
                    onReplaceAll = viewModel::replaceAll,
                    onClose = { viewModel.setFindVisible(false) }
                )
            }
            state.activeTab?.let { tab ->
                MarkdownWorkspace(
                    modifier = Modifier.weight(1f),
                    tab = tab,
                    fontSize = state.settings.fontSizeSp,
                    wordWrap = state.settings.wordWrap,
                    lineNumbers = state.settings.lineNumbers,
                    syntaxHighlighting = state.settings.syntaxHighlighting,
                    focusRequester = focusRequester,
                    imeVisible = imeVisible,
                    previewVisible = state.markdownPreviewVisible && tab.isMarkdown && state.settings.markdownPreview,
                    onValueChange = viewModel::updateText
                )
            }
        }
    }

    pendingClose?.let { tab ->
        AlertDialog(
            onDismissRequest = { pendingClose = null },
            title = { Text("Unsaved changes") },
            text = { Text("Save changes to ${tab.title} before closing?") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.selectTab(tab.id)
                    pendingClose = null
                    if (tab.uri == null) {
                        closeAfterSaveTabId = tab.id
                        saveAsLauncher.launch(suggestedSaveName(tab.title))
                    } else viewModel.saveCurrent(context) { viewModel.closeTab(tab.id) }
                }) { Text("Save") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { pendingClose = null }) { Text("Cancel") }
                    TextButton(onClick = { pendingClose = null; viewModel.closeTab(tab.id) }) { Text("Don't Save") }
                }
            }
        )
    }

    if (state.settingsVisible) SettingsDialog(viewModel)
    if (state.recentVisible) RecentFilesDialog(viewModel)
    if (state.goToLineVisible) GoToLineDialog(viewModel)
    if (state.fileInfoVisible) FileInfoDialog(viewModel)
    if (state.newFileVisible) NewFileDialog(viewModel)
    if (aboutVisible) AboutDialog { aboutVisible = false }
}

@Composable
private fun JinPadTopBar(
    tabs: List<EditorTab>,
    activeTabId: String,
    activeTab: EditorTab?,
    openMenu: DesktopMenu?,
    canUndo: Boolean,
    canRedo: Boolean,
    wordWrap: Boolean,
    lineNumbers: Boolean,
    statusBar: Boolean,
    syntaxHighlighting: Boolean,
    markdownPreview: Boolean,
    onMenuChange: (DesktopMenu?) -> Unit,
    onSelect: (String) -> Unit,
    onClose: (String) -> Unit,
    onCloseOthers: (String) -> Unit,
    onCloseAllClean: () -> Unit,
    onMoveTab: (String, Int) -> Unit,
    onNew: () -> Unit,
    onNewType: () -> Unit,
    onOpen: () -> Unit,
    onSave: () -> Unit,
    onSaveAs: () -> Unit,
    onRecent: () -> Unit,
    onFileInfo: () -> Unit,
    onShare: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onCut: () -> Unit,
    onCopy: () -> Unit,
    onPaste: () -> Unit,
    onFind: () -> Unit,
    onReplace: () -> Unit,
    onGoToLine: () -> Unit,
    onDuplicateLine: () -> Unit,
    onIndent: () -> Unit,
    onUnindent: () -> Unit,
    onSelectAll: () -> Unit,
    onFormat: () -> Unit,
    onEncoding: (TextEncoding) -> Unit,
    onLineEnding: (LineEnding) -> Unit,
    onWordWrap: (Boolean) -> Unit,
    onLineNumbers: (Boolean) -> Unit,
    onStatusBar: (Boolean) -> Unit,
    onSyntaxHighlighting: (Boolean) -> Unit,
    onMarkdownPreview: (Boolean) -> Unit,
    onZoomOut: () -> Unit,
    onZoomIn: () -> Unit,
    onZoomReset: () -> Unit,
    onSettings: () -> Unit,
    onAbout: () -> Unit
) {
    Column(Modifier.fillMaxWidth().statusBarsPadding()) {
        Surface(tonalElevation = 3.dp) {
            Row(
                Modifier.fillMaxWidth().height(44.dp).padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                JinPadLogo(30.dp)
                Spacer(Modifier.width(9.dp))
                Text("JinPad", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.width(10.dp))
                Text(
                    text = activeTab?.let { if (it.isDirty) "${it.title} •" else it.title } ?: "Untitled.txt",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = onFind, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Find") }
            }
        }

        TabsBar(
            tabs = tabs,
            activeTabId = activeTabId,
            onSelect = onSelect,
            onClose = onClose,
            onCloseOthers = onCloseOthers,
            onCloseAllClean = onCloseAllClean,
            onMoveTab = onMoveTab,
            onNew = onNew
        )

        Surface(tonalElevation = 2.dp) {
            Row(
                Modifier.fillMaxWidth().height(38.dp).horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                DesktopMenuButton("File", openMenu == DesktopMenu.FILE, { onMenuChange(if (it) DesktopMenu.FILE else null) }) {
                    MenuItem("New", "Ctrl+N") { onMenuChange(null); onNew() }
                    MenuItem("New file type…", "Ctrl+Shift+N") { onMenuChange(null); onNewType() }
                    MenuItem("Open…", "Ctrl+O") { onMenuChange(null); onOpen() }
                    HorizontalDivider()
                    MenuItem("Save", "Ctrl+S") { onMenuChange(null); onSave() }
                    MenuItem("Save As…", "Ctrl+Shift+S") { onMenuChange(null); onSaveAs() }
                    HorizontalDivider()
                    MenuItem("Recent Files") { onMenuChange(null); onRecent() }
                    MenuItem("Properties") { onMenuChange(null); onFileInfo() }
                    MenuItem("Share") { onMenuChange(null); onShare() }
                }

                DesktopMenuButton("Edit", openMenu == DesktopMenu.EDIT, { onMenuChange(if (it) DesktopMenu.EDIT else null) }) {
                    MenuItem("Undo", "Ctrl+Z", canUndo) { onMenuChange(null); onUndo() }
                    MenuItem("Redo", "Ctrl+Y", canRedo) { onMenuChange(null); onRedo() }
                    HorizontalDivider()
                    MenuItem("Cut", "Ctrl+X") { onMenuChange(null); onCut() }
                    MenuItem("Copy", "Ctrl+C") { onMenuChange(null); onCopy() }
                    MenuItem("Paste", "Ctrl+V") { onMenuChange(null); onPaste() }
                    MenuItem("Select All", "Ctrl+A") { onMenuChange(null); onSelectAll() }
                    HorizontalDivider()
                    MenuItem("Find", "Ctrl+F") { onMenuChange(null); onFind() }
                    MenuItem("Replace", "Ctrl+H") { onMenuChange(null); onReplace() }
                    MenuItem("Go to Line…", "Ctrl+G") { onMenuChange(null); onGoToLine() }
                    HorizontalDivider()
                    MenuItem("Duplicate Line", "Ctrl+D") { onMenuChange(null); onDuplicateLine() }
                    MenuItem("Indent") { onMenuChange(null); onIndent() }
                    MenuItem("Unindent") { onMenuChange(null); onUnindent() }
                }

                DesktopMenuButton("Format", openMenu == DesktopMenu.FORMAT, { onMenuChange(if (it) DesktopMenu.FORMAT else null) }) {
                    MenuItem("Format JSON / XML") { onMenuChange(null); onFormat() }
                    HorizontalDivider()
                    Text("Encoding", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(12.dp, 6.dp))
                    TextEncoding.entries.forEach { enc ->
                        MenuItem(if (activeTab?.encoding == enc) "✓  ${enc.label}" else enc.label) { onMenuChange(null); onEncoding(enc) }
                    }
                    HorizontalDivider()
                    Text("Line endings", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(12.dp, 6.dp))
                    LineEnding.entries.forEach { ending ->
                        MenuItem(if (activeTab?.lineEnding == ending) "✓  ${ending.label}" else ending.label) { onMenuChange(null); onLineEnding(ending) }
                    }
                }

                DesktopMenuButton("View", openMenu == DesktopMenu.VIEW, { onMenuChange(if (it) DesktopMenu.VIEW else null) }) {
                    MenuItem(if (wordWrap) "✓  Word Wrap" else "Word Wrap") { onMenuChange(null); onWordWrap(!wordWrap) }
                    MenuItem(if (lineNumbers) "✓  Line Numbers" else "Line Numbers") { onMenuChange(null); onLineNumbers(!lineNumbers) }
                    MenuItem(if (statusBar) "✓  Status Bar" else "Status Bar") { onMenuChange(null); onStatusBar(!statusBar) }
                    MenuItem(if (syntaxHighlighting) "✓  Syntax Highlighting" else "Syntax Highlighting") { onMenuChange(null); onSyntaxHighlighting(!syntaxHighlighting) }
                    if (activeTab?.isMarkdown == true) {
                        MenuItem(if (markdownPreview) "✓  Markdown Preview" else "Markdown Preview") { onMenuChange(null); onMarkdownPreview(!markdownPreview) }
                    }
                    HorizontalDivider()
                    MenuItem("Zoom In", "Ctrl++") { onMenuChange(null); onZoomIn() }
                    MenuItem("Zoom Out", "Ctrl+-") { onMenuChange(null); onZoomOut() }
                    MenuItem("Restore Default Zoom", "Ctrl+0") { onMenuChange(null); onZoomReset() }
                    HorizontalDivider()
                    MenuItem("Settings") { onMenuChange(null); onSettings() }
                }

                DesktopMenuButton("Help", openMenu == DesktopMenu.HELP, { onMenuChange(if (it) DesktopMenu.HELP else null) }) {
                    MenuItem("About JinPad") { onMenuChange(null); onAbout() }
                }

                Spacer(Modifier.width(8.dp))
                Text(
                    activeTab?.encoding?.label ?: "UTF-8",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun JinPadLogo(size: androidx.compose.ui.unit.Dp) {
    Surface(
        modifier = Modifier.size(size),
        shape = RoundedCornerShape(7.dp),
        color = MaterialTheme.colorScheme.primary
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text("J", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.ExtraBold, fontSize = (size.value * 0.58f).sp)
        }
    }
}

@Composable
private fun DesktopMenuButton(
    label: String,
    expanded: Boolean,
    onExpandedChange: (Boolean) -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Box {
        TextButton(
            onClick = { onExpandedChange(!expanded) },
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
            modifier = Modifier.height(34.dp)
        ) { Text(label) }
        DropdownMenu(expanded = expanded, onDismissRequest = { onExpandedChange(false) }, content = content)
    }
}

@Composable
private fun ColumnScope.MenuItem(
    label: String,
    shortcut: String? = null,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    DropdownMenuItem(
        text = {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(label, modifier = Modifier.weight(1f))
                if (!shortcut.isNullOrBlank()) Text(shortcut, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        enabled = enabled,
        onClick = onClick
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TabsBar(
    tabs: List<EditorTab>,
    activeTabId: String,
    onSelect: (String) -> Unit,
    onClose: (String) -> Unit,
    onCloseOthers: (String) -> Unit,
    onCloseAllClean: () -> Unit,
    onMoveTab: (String, Int) -> Unit,
    onNew: () -> Unit
) {
    Surface(tonalElevation = 1.dp) {
        LazyRow(
            Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items(tabs, key = { it.id }) { tab ->
                var contextOpen by remember(tab.id) { mutableStateOf(false) }
                Box {
                    Surface(
                        shape = RoundedCornerShape(topStart = 7.dp, topEnd = 7.dp, bottomStart = 3.dp, bottomEnd = 3.dp),
                        color = if (tab.id == activeTabId) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface,
                        border = if (tab.id == activeTabId) BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant) else null,
                        modifier = Modifier.combinedClickable(onClick = { onSelect(tab.id) }, onLongClick = { contextOpen = true })
                    ) {
                        Row(Modifier.height(40.dp).padding(start = 11.dp, end = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                if (tab.isDirty) "${tab.title} •" else tab.title,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.widthIn(max = 165.dp)
                            )
                            TextButton(onClick = { onClose(tab.id) }, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(32.dp)) {
                                Text("×", fontSize = 18.sp)
                            }
                        }
                    }
                    DropdownMenu(expanded = contextOpen, onDismissRequest = { contextOpen = false }) {
                        DropdownMenuItem(text = { Text("Close") }, onClick = { contextOpen = false; onClose(tab.id) })
                        DropdownMenuItem(text = { Text("Close Others") }, onClick = { contextOpen = false; onCloseOthers(tab.id) })
                        DropdownMenuItem(text = { Text("Close All Clean Tabs") }, onClick = { contextOpen = false; onCloseAllClean() })
                        HorizontalDivider()
                        DropdownMenuItem(text = { Text("Move Left") }, onClick = { contextOpen = false; onMoveTab(tab.id, -1) })
                        DropdownMenuItem(text = { Text("Move Right") }, onClick = { contextOpen = false; onMoveTab(tab.id, 1) })
                    }
                }
            }
            item {
                TextButton(onClick = onNew, modifier = Modifier.size(40.dp), contentPadding = PaddingValues(0.dp)) { Text("+", fontSize = 20.sp) }
            }
        }
    }
}

@Composable
private fun MarkdownWorkspace(
    modifier: Modifier,
    tab: EditorTab,
    fontSize: Float,
    wordWrap: Boolean,
    lineNumbers: Boolean,
    syntaxHighlighting: Boolean,
    focusRequester: FocusRequester,
    imeVisible: Boolean,
    previewVisible: Boolean,
    onValueChange: (TextFieldValue) -> Unit
) {
    BoxWithConstraints(modifier.fillMaxSize()) {
        val wide = maxWidth >= 720.dp
        if (previewVisible && wide) {
            Row(Modifier.fillMaxSize()) {
                EditorPane(
                    Modifier.weight(1f), tab, fontSize, wordWrap, lineNumbers, syntaxHighlighting,
                    focusRequester, imeVisible, onValueChange
                )
                VerticalDivider()
                MarkdownPreview(Modifier.weight(1f), tab.value.text)
            }
        } else if (previewVisible) {
            MarkdownPreview(Modifier.fillMaxSize(), tab.value.text)
        } else {
            EditorPane(
                Modifier.fillMaxSize(), tab, fontSize, wordWrap, lineNumbers, syntaxHighlighting,
                focusRequester, imeVisible, onValueChange
            )
        }
    }
}

@Composable
private fun EditorPane(
    modifier: Modifier = Modifier,
    tab: EditorTab,
    fontSize: Float,
    wordWrap: Boolean,
    lineNumbers: Boolean,
    syntaxHighlighting: Boolean,
    focusRequester: FocusRequester,
    imeVisible: Boolean,
    onValueChange: (TextFieldValue) -> Unit
) {
    val verticalScroll = rememberScrollState()
    val horizontalScroll = rememberScrollState()
    val bringIntoViewRequester = remember { BringIntoViewRequester() }
    val density = LocalDensity.current
    var textLayoutResult by remember { mutableStateOf<TextLayoutResult?>(null) }
    val lineCount = remember(tab.value.text) { tab.value.text.count { it == '\n' } + 1 }
    val scheme = MaterialTheme.colorScheme
    val transformation: VisualTransformation = remember(tab.extension, syntaxHighlighting, tab.isLargeFile, scheme) {
        if (!syntaxHighlighting || tab.isLargeFile) VisualTransformation.None
        else CodeVisualTransformation(
            tab.extension,
            SyntaxColors(
                keyword = if (scheme.background.luminanceCompat() < 0.5f) Color(0xFF569CD6) else Color(0xFF0000AA),
                string = if (scheme.background.luminanceCompat() < 0.5f) Color(0xFFCE9178) else Color(0xFFA31515),
                comment = if (scheme.background.luminanceCompat() < 0.5f) Color(0xFF6A9955) else Color(0xFF008000),
                number = if (scheme.background.luminanceCompat() < 0.5f) Color(0xFFB5CEA8) else Color(0xFF098658),
                tag = if (scheme.background.luminanceCompat() < 0.5f) Color(0xFF4EC9B0) else Color(0xFF800000),
                property = if (scheme.background.luminanceCompat() < 0.5f) Color(0xFF9CDCFE) else Color(0xFF0451A5)
            )
        )
    }

    LaunchedEffect(tab.value.selection.end, tab.value.text.length, imeVisible) {
        if (!imeVisible) return@LaunchedEffect
        delay(70)
        val layout = textLayoutResult ?: return@LaunchedEffect
        val offset = tab.value.selection.end.coerceIn(0, tab.value.text.length)
        val cursorRect = layout.getCursorRect(offset)
        val extraBottom = with(density) { 96.dp.toPx() }
        val extraTop = with(density) { 32.dp.toPx() }
        bringIntoViewRequester.bringIntoView(
            Rect(cursorRect.left, (cursorRect.top - extraTop).coerceAtLeast(0f), cursorRect.right + 16f, cursorRect.bottom + extraBottom)
        )
    }

    BoxWithConstraints(modifier.fillMaxSize()) {
        val viewportMinHeight = (maxHeight - 8.dp).coerceAtLeast(180.dp)
        Row(
            Modifier.fillMaxSize().verticalScroll(verticalScroll).padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            if (lineNumbers) {
                Text(
                    (1..lineCount).joinToString("\n"),
                    fontFamily = FontFamily.Monospace,
                    fontSize = fontSize.sp,
                    lineHeight = (fontSize * 1.48f).sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.62f),
                    modifier = Modifier.padding(end = 10.dp)
                )
                VerticalDivider(Modifier.heightIn(min = viewportMinHeight).padding(end = 8.dp), color = MaterialTheme.colorScheme.outlineVariant)
            }
            Box(Modifier.weight(1f).then(if (wordWrap) Modifier else Modifier.horizontalScroll(horizontalScroll))) {
                androidx.compose.foundation.text.BasicTextField(
                    value = tab.value,
                    onValueChange = onValueChange,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(
                        color = MaterialTheme.colorScheme.onSurface,
                        fontFamily = FontFamily.Monospace,
                        fontSize = fontSize.sp,
                        lineHeight = (fontSize * 1.48f).sp
                    ),
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                    visualTransformation = transformation,
                    onTextLayout = { textLayoutResult = it },
                    modifier = Modifier
                        .focusRequester(focusRequester)
                        .bringIntoViewRequester(bringIntoViewRequester)
                        .heightIn(min = viewportMinHeight)
                        .then(if (wordWrap) Modifier.fillMaxWidth() else Modifier.widthIn(min = 1800.dp))
                )
            }
        }
    }
}

private fun Color.luminanceCompat(): Float {
    val r = red; val g = green; val b = blue
    return 0.2126f * r + 0.7152f * g + 0.0722f * b
}

@Composable
private fun MarkdownPreview(modifier: Modifier, markdown: String) {
    Column(
        modifier.background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        var inCode = false
        markdown.lines().forEach { line ->
            when {
                line.trim().startsWith("```") -> {
                    inCode = !inCode
                    if (!inCode) Spacer(Modifier.height(2.dp))
                }
                inCode -> Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(5.dp)) {
                    Text(line, fontFamily = FontFamily.Monospace, modifier = Modifier.fillMaxWidth().padding(8.dp), style = MaterialTheme.typography.bodySmall)
                }
                line.startsWith("### ") -> Text(line.removePrefix("### "), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                line.startsWith("## ") -> Text(line.removePrefix("## "), fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                line.startsWith("# ") -> Text(line.removePrefix("# "), fontSize = 25.sp, fontWeight = FontWeight.Bold)
                line.startsWith("> ") -> Surface(color = MaterialTheme.colorScheme.surfaceVariant) {
                    Text(line.removePrefix("> "), modifier = Modifier.fillMaxWidth().padding(8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                line.startsWith("- ") || line.startsWith("* ") -> Text("•  " + line.drop(2), style = MaterialTheme.typography.bodyLarge)
                line.matches(Regex("^\\d+\\.\\s+.*")) -> Text(line, style = MaterialTheme.typography.bodyLarge)
                line.trim().matches(Regex("^[-*_]{3,}$")) -> HorizontalDivider()
                line.isBlank() -> Spacer(Modifier.height(5.dp))
                else -> Text(markdownInline(line), style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
}

private fun markdownInline(line: String): AnnotatedString = buildAnnotatedString {
    var cursor = 0
    val code = Regex("`([^`]+)`")
    code.findAll(line).forEach { match ->
        if (match.range.first > cursor) append(line.substring(cursor, match.range.first))
        pushStyle(androidx.compose.ui.text.SpanStyle(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Medium))
        append(match.groupValues[1])
        pop()
        cursor = match.range.last + 1
    }
    if (cursor < line.length) append(line.substring(cursor))
}

@Composable
private fun QuickToolbar(
    canUndo: Boolean,
    canRedo: Boolean,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onFind: () -> Unit,
    onSave: () -> Unit,
    onGoToLine: () -> Unit,
    onZoomOut: () -> Unit,
    onZoomIn: () -> Unit
) {
    Surface(tonalElevation = 3.dp) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp, vertical = 1.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(enabled = canUndo, onClick = onUndo) { Text("Undo") }
            TextButton(enabled = canRedo, onClick = onRedo) { Text("Redo") }
            TextButton(onClick = onFind) { Text("Find") }
            TextButton(onClick = onSave) { Text("Save") }
            TextButton(onClick = onGoToLine) { Text("Ln") }
            TextButton(onClick = onZoomOut) { Text("A−") }
            TextButton(onClick = onZoomIn) { Text("A+") }
        }
    }
}

@Composable
private fun CodeKeyboardToolbar(
    tabWidth: Int,
    onInsert: (String) -> Unit,
    onIndent: () -> Unit,
    onUnindent: () -> Unit,
    onDuplicate: () -> Unit,
    onSave: () -> Unit
) {
    Surface(tonalElevation = 5.dp, shadowElevation = 2.dp) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            SmallToolButton("Tab") { onInsert(" ".repeat(tabWidth)) }
            SmallToolButton("⇥") { onIndent() }
            SmallToolButton("⇤") { onUnindent() }
            listOf("{}", "()", "[]", "\"\"", ":", ";", "/", "#").forEach { token ->
                SmallToolButton(token) {
                    val insert = when (token) {
                        "{}" -> "{}"
                        "()" -> "()"
                        "[]" -> "[]"
                        "\"\"" -> "\"\""
                        else -> token
                    }
                    onInsert(insert)
                }
            }
            SmallToolButton("Dup") { onDuplicate() }
            SmallToolButton("Save") { onSave() }
        }
    }
}

@Composable
private fun SmallToolButton(label: String, onClick: () -> Unit) {
    TextButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp), modifier = Modifier.height(42.dp)) { Text(label) }
}

@Composable
private fun StatusBar(tab: EditorTab?, fontSize: Float) {
    val text = tab?.value?.text.orEmpty()
    val cursor = tab?.value?.selection?.start?.coerceIn(0, text.length) ?: 0
    val before = text.take(cursor)
    val line = before.count { it == '\n' } + 1
    val column = cursor - (before.lastIndexOf('\n').takeIf { it >= 0 } ?: -1)
    val words = if (tab?.isLargeFile == true) null else remember(text) { Regex("\\S+").findAll(text).count() }
    val zoom = ((fontSize / 17f) * 100).toInt()
    Surface(tonalElevation = 2.dp) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Ln $line, Col $column", style = MaterialTheme.typography.labelSmall)
            StatusSeparator(); Text(words?.let { "$it words" } ?: "Large file", style = MaterialTheme.typography.labelSmall)
            StatusSeparator(); Text("${text.length} chars", style = MaterialTheme.typography.labelSmall)
            StatusSeparator(); Text(tab?.encoding?.label ?: "UTF-8", style = MaterialTheme.typography.labelSmall)
            StatusSeparator(); Text(tab?.lineEnding?.label ?: "LF", style = MaterialTheme.typography.labelSmall)
            StatusSeparator(); Text("$zoom%", style = MaterialTheme.typography.labelSmall)
            tab?.extension?.takeIf { it.isNotBlank() }?.let { StatusSeparator(); Text(it.uppercase(), style = MaterialTheme.typography.labelSmall) }
        }
    }
}

@Composable
private fun StatusSeparator() { Text("  |  ", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline) }

@Composable
private fun FindReplaceBar(
    query: String,
    replace: String,
    replaceVisible: Boolean,
    matchCase: Boolean,
    wholeWord: Boolean,
    regex: Boolean,
    onQuery: (String) -> Unit,
    onReplace: (String) -> Unit,
    onMatchCase: (Boolean) -> Unit,
    onWholeWord: (Boolean) -> Unit,
    onRegex: (Boolean) -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onReplaceOne: () -> Unit,
    onReplaceAll: () -> Unit,
    onClose: () -> Unit
) {
    Surface(tonalElevation = 5.dp, shadowElevation = 2.dp) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(query, onQuery, placeholder = { Text("Find") }, singleLine = true, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(4.dp)); TextButton(onClick = onPrev) { Text("↑") }; TextButton(onClick = onNext) { Text("↓") }; TextButton(onClick = onClose) { Text("×") }
            }
            if (replaceVisible) {
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(replace, onReplace, placeholder = { Text("Replace with") }, singleLine = true, modifier = Modifier.weight(1f))
                    TextButton(onClick = onReplaceOne) { Text("Replace") }; TextButton(onClick = onReplaceAll) { Text("All") }
                }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                CompactCheck("Match case", matchCase, onMatchCase)
                CompactCheck("Whole word", wholeWord, onWholeWord)
                CompactCheck("Regex", regex, onRegex)
            }
        }
    }
}

@Composable
private fun CompactCheck(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked, onChecked); Text(label, style = MaterialTheme.typography.labelMedium); Spacer(Modifier.width(6.dp))
    }
}

@Composable
private fun SettingsDialog(viewModel: EditorViewModel) {
    val settings = viewModel.uiState.settings
    AlertDialog(
        onDismissRequest = { viewModel.showSettings(false) },
        title = { Text("JinPad Settings") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                SectionTitle("Appearance")
                ThemeMode.entries.forEach { mode ->
                    Row(Modifier.fillMaxWidth().clickable { viewModel.setTheme(mode) }.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(settings.themeMode == mode, onClick = { viewModel.setTheme(mode) })
                        Text(mode.name.lowercase().replaceFirstChar { it.uppercase() })
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 6.dp))
                SectionTitle("Editor")
                SettingSwitch("Word Wrap", settings.wordWrap, viewModel::setWordWrap)
                SettingSwitch("Line Numbers", settings.lineNumbers, viewModel::setLineNumbers)
                SettingSwitch("Syntax Highlighting", settings.syntaxHighlighting, viewModel::setSyntaxHighlighting)
                SettingSwitch("Markdown Preview", settings.markdownPreview, viewModel::setMarkdownPreview)
                SettingSwitch("Status Bar", settings.showStatusBar, viewModel::setShowStatusBar)
                SettingSwitch("Quick / Keyboard Toolbar", settings.showQuickToolbar, viewModel::setShowQuickToolbar)
                Spacer(Modifier.height(6.dp))
                Text("Font size: ${settings.fontSizeSp.toInt()} sp")
                Slider(settings.fontSizeSp, viewModel::setFontSize, valueRange = 10f..34f)
                Text("Tab width")
                Row { listOf(2, 4, 8).forEach { w -> FilterChip(selected = settings.tabWidth == w, onClick = { viewModel.setTabWidth(w) }, label = { Text("$w") }, modifier = Modifier.padding(end = 6.dp)) } }
                HorizontalDivider(Modifier.padding(vertical = 6.dp))
                SectionTitle("Files & Recovery")
                SettingSwitch("Auto Save existing files", settings.autoSave, viewModel::setAutoSave)
                if (settings.autoSave) {
                    Text("Auto-save delay: ${settings.autoSaveDelaySeconds}s")
                    Slider(settings.autoSaveDelaySeconds.toFloat(), { viewModel.setAutoSaveDelay(it.toInt()) }, valueRange = 1f..10f, steps = 8)
                }
                SettingSwitch("Restore Session / Crash Recovery", settings.sessionRestore, viewModel::setSessionRestore)
                Text("Default encoding", style = MaterialTheme.typography.labelMedium)
                TextEncoding.entries.forEach { enc -> RadioLine(enc.label, settings.defaultEncoding == enc) { viewModel.setDefaultEncoding(enc) } }
                Text("Default line endings", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 5.dp))
                LineEnding.entries.forEach { ending -> RadioLine(ending.label, settings.defaultLineEnding == ending) { viewModel.setDefaultLineEnding(ending) } }
                Text(
                    "Auto Save only writes files that already have a saved location. Unsaved tabs are protected by session recovery.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        },
        confirmButton = { TextButton(onClick = { viewModel.showSettings(false) }) { Text("Done") } }
    )
}

@Composable private fun SectionTitle(text: String) { Text(text, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary) }

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f)); Switch(checked, onChecked)
    }
}

@Composable
private fun RadioLine(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 1.dp), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected, onClick = onClick); Text(label)
    }
}

@Composable
private fun RecentFilesDialog(viewModel: EditorViewModel) {
    val state = viewModel.uiState
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = { viewModel.showRecent(false) },
        title = { Text("Recent Files") },
        text = {
            if (state.recentFiles.isEmpty()) Text("No recent files yet.")
            else Column(Modifier.verticalScroll(rememberScrollState())) {
                state.recentFiles.forEach { file ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(
                            Modifier.weight(1f).clickable {
                                viewModel.showRecent(false); viewModel.openRecent(context, file.uri)
                            }
                        ) {
                            Text((if (file.pinned) "★  " else "") + file.title, style = MaterialTheme.typography.bodyLarge)
                            Text(DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(file.lastOpenedAt)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(file.uri, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        TextButton(onClick = { viewModel.toggleRecentPin(file.uri) }) { Text(if (file.pinned) "Unpin" else "Pin") }
                        TextButton(onClick = { viewModel.removeRecent(file.uri) }) { Text("×") }
                    }
                    HorizontalDivider()
                }
            }
        },
        confirmButton = { TextButton(onClick = { viewModel.showRecent(false) }) { Text("Close") } },
        dismissButton = { TextButton(onClick = viewModel::clearRecent) { Text("Clear unpinned") } }
    )
}

@Composable
private fun GoToLineDialog(viewModel: EditorViewModel) {
    var value by remember { mutableStateOf("") }
    val maxLines = viewModel.uiState.activeTab?.value?.text?.count { it == '\n' }?.plus(1) ?: 1
    AlertDialog(
        onDismissRequest = { viewModel.showGoToLine(false) },
        title = { Text("Go to Line") },
        text = { OutlinedTextField(value, { value = it.filter(Char::isDigit) }, label = { Text("Line 1–$maxLines") }, singleLine = true) },
        confirmButton = { TextButton(onClick = { viewModel.goToLine(value.toIntOrNull() ?: 1) }) { Text("Go") } },
        dismissButton = { TextButton(onClick = { viewModel.showGoToLine(false) }) { Text("Cancel") } }
    )
}

@Composable
private fun FileInfoDialog(viewModel: EditorViewModel) {
    val tab = viewModel.uiState.activeTab
    val text = tab?.value?.text.orEmpty()
    val lines = text.count { it == '\n' } + 1
    val words = if (tab?.isLargeFile == true) "Large file" else Regex("\\S+").findAll(text).count().toString()
    val bytes = tab?.let { FileUtils.estimatedBytes(text, it.encoding) } ?: 0
    AlertDialog(
        onDismissRequest = { viewModel.showFileInfo(false) },
        title = { Text("Properties") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                PropertyLine("Name", tab?.title ?: "Untitled.txt")
                PropertyLine("Location", tab?.uri ?: "Not saved yet")
                PropertyLine("Type", tab?.extension?.uppercase().orEmpty().ifBlank { "Text" })
                PropertyLine("Encoding", tab?.encoding?.label ?: "UTF-8")
                PropertyLine("Line endings", tab?.lineEnding?.label ?: "LF")
                PropertyLine("Lines", "$lines")
                PropertyLine("Words", words)
                PropertyLine("Characters", "${text.length}")
                PropertyLine("Estimated size", formatBytes(bytes.toLong()))
            }
        },
        confirmButton = { TextButton(onClick = { viewModel.showFileInfo(false) }) { Text("OK") } }
    )
}

@Composable private fun PropertyLine(label: String, value: String) {
    Column { Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(value, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis) }
}

@Composable
private fun NewFileDialog(viewModel: EditorViewModel) {
    val types = listOf(
        "txt" to "Text (.txt)", "md" to "Markdown (.md)", "json" to "JSON (.json)", "xml" to "XML (.xml)",
        "html" to "HTML (.html)", "css" to "CSS (.css)", "js" to "JavaScript (.js)", "py" to "Python (.py)",
        "java" to "Java (.java)", "kt" to "Kotlin (.kt)", "csv" to "CSV (.csv)", "log" to "Log (.log)"
    )
    AlertDialog(
        onDismissRequest = { viewModel.showNewFile(false) },
        title = { Text("New File") },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) { types.forEach { (ext, label) -> TextButton(onClick = { viewModel.newTab(ext) }, modifier = Modifier.fillMaxWidth()) { Text(label, modifier = Modifier.fillMaxWidth()) } } } },
        confirmButton = {},
        dismissButton = { TextButton(onClick = { viewModel.showNewFile(false) }) { Text("Cancel") } }
    )
}

@Composable
private fun AboutDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { JinPadLogo(48.dp) },
        title = { Text("JinPad 1.0") },
        text = {
            Text("A fast, offline text and code editor for Android. No login, no ads, no Internet permission. Designed with a clean desktop-style workflow while keeping its own JinPad identity.")
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } }
    )
}

private fun suggestedSaveName(title: String): String {
    val trimmed = title.trim().ifEmpty { "Untitled.txt" }
    return if ('.' in trimmed) trimmed else "$trimmed.txt"
}

private fun formatBytes(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
    else -> "%.1f MB".format(bytes / (1024.0 * 1024.0))
}
