# Jin Notepad v0.2.0

A fast, offline Android text editor inspired by the simplicity of desktop Notepad, with a mobile-first layout.

## v0.2 highlights

- Fixed Android status/navigation bar spacing so the title and bottom controls are not clipped.
- Fixed popup menu anchoring; menus now open from the control that was tapped.
- Fixed editor/keyboard behavior: the editor resizes for the IME and keeps the caret visible when editing lower lines.
- Windows-style `File / Edit / View` menu bar.
- Refined tabs, title bar, neutral Windows-like light/dark palette and status bar.
- New Select All command and `Ctrl+A`.
- Optional Auto Save for already-saved files.
- Optional bottom quick toolbar.
- Existing features retained: New/Open/Save/Save As, multiple tabs, Undo/Redo, Find/Replace, Word Wrap, line numbers, zoom, recent files, session restore, Android Open With and sharing.

## Build

The project targets Android API 36 and Java 17.

```bash
chmod +x gradlew
./gradlew clean :app:assembleDebug
```

Debug APK output:

`app/build/outputs/apk/debug/app-debug.apk`
