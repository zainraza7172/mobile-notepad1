# Notepad 1.0

Notepad is a fast Android text/code editor with a clean desktop-style workflow and Android-native file handling.

## Final features
- New / Open / Save / Save As through Android Storage Access Framework
- Multiple tabs, tab reordering, close/close-others/close-clean-tabs
- Undo / Redo, Cut / Copy / Paste, Select All
- Find / Replace / Replace All, case/whole-word/regex search
- Go to Line, duplicate line, indent/unindent
- Word wrap, line numbers, status bar, zoom
- UTF-8, UTF-8 BOM, UTF-16 LE/BE
- LF / CRLF / CR line endings
- Syntax highlighting for common text/code formats
- Markdown preview
- HTML preview with inline HTML/CSS/JavaScript execution inside a sandboxed WebView
- Session restore and crash recovery
- Optional auto-save for existing files
- Optional Google Drive/cloud-folder backup using Android's folder picker
- Restore open tabs, text, editor settings and recent-file metadata after reinstall
- Android system cloud backup/device-transfer support for app data
- Light / Dark / System theme
- Open With / Share support
- No ads

## Google Drive backup
Open Settings > Google Drive Backup > Connect Google Drive Folder. Choose a folder from Google Drive in the Android folder picker. Notepad creates `Notepad-Backup.json`. After reinstalling, connect the same folder and tap Restore. Restored file contents open as safe local copies because Android URI permissions do not survive uninstall/reinstall.

## HTML preview
Create or open `.html`/`.htm`, then tap Run or View > HTML Preview. Inline CSS and JavaScript run in the preview. File/content access is disabled in the WebView.

## Build
Requires JDK 17, Android SDK 36 and Build Tools 36.0.0.

Package: `com.jin.notepad`
Version: `1.0.0`
