package com.jin.notepad.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jin.notepad.data.SessionStore
import com.jin.notepad.data.SettingsStore
import com.jin.notepad.model.EditorSettings
import com.jin.notepad.model.EditorTab
import com.jin.notepad.model.EditorUiState
import com.jin.notepad.model.RecentFile
import com.jin.notepad.model.ThemeMode
import com.jin.notepad.util.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class EditorViewModel(application: Application) : AndroidViewModel(application) {
    private val settingsStore = SettingsStore(application)
    private val sessionStore = SessionStore(application)
    private var sessionSaveJob: Job? = null

    var uiState by mutableStateOf(initialState())
        private set

    private fun initialState(): EditorUiState {
        val settings = settingsStore.loadSettings()
        val recent = settingsStore.loadRecentFiles()
        if (settings.sessionRestore) {
            val restored = sessionStore.load()
            if (restored != null) {
                val (tabs, activeId) = restored
                val resolvedActive = activeId?.takeIf { id -> tabs.any { it.id == id } } ?: tabs.first().id
                return EditorUiState(
                    tabs = tabs,
                    activeTabId = resolvedActive,
                    settings = settings,
                    recentFiles = recent
                )
            }
        }
        val first = EditorTab(title = "Untitled 1")
        return EditorUiState(tabs = listOf(first), activeTabId = first.id, settings = settings, recentFiles = recent)
    }

    fun newTab() {
        val next = nextUntitledNumber()
        val tab = EditorTab(title = "Untitled $next")
        uiState = uiState.copy(tabs = uiState.tabs + tab, activeTabId = tab.id)
        scheduleSessionSave()
    }

    fun selectTab(id: String) {
        if (uiState.tabs.any { it.id == id }) {
            uiState = uiState.copy(activeTabId = id)
            scheduleSessionSave()
        }
    }

    fun closeTab(id: String) {
        val remaining = uiState.tabs.filterNot { it.id == id }
        if (remaining.isEmpty()) {
            val fresh = EditorTab(title = "Untitled 1")
            uiState = uiState.copy(tabs = listOf(fresh), activeTabId = fresh.id)
        } else {
            val active = if (uiState.activeTabId == id) remaining.last().id else uiState.activeTabId
            uiState = uiState.copy(tabs = remaining, activeTabId = active)
        }
        scheduleSessionSave()
    }

    fun updateText(value: TextFieldValue) {
        val active = uiState.activeTab ?: return
        val updated = if (value.text != active.value.text) {
            active.copy(
                value = value,
                undoStack = (active.undoStack + active.value).takeLast(200),
                redoStack = emptyList()
            )
        } else {
            active.copy(value = value)
        }
        replaceTab(updated)
        scheduleSessionSave()
    }

    fun undo() {
        val tab = uiState.activeTab ?: return
        val previous = tab.undoStack.lastOrNull() ?: return
        replaceTab(
            tab.copy(
                value = previous,
                undoStack = tab.undoStack.dropLast(1),
                redoStack = (tab.redoStack + tab.value).takeLast(200)
            )
        )
        scheduleSessionSave()
    }

    fun redo() {
        val tab = uiState.activeTab ?: return
        val next = tab.redoStack.lastOrNull() ?: return
        replaceTab(
            tab.copy(
                value = next,
                redoStack = tab.redoStack.dropLast(1),
                undoStack = (tab.undoStack + tab.value).takeLast(200)
            )
        )
        scheduleSessionSave()
    }

    fun openUri(context: Context, uri: Uri) {
        val existing = uiState.tabs.firstOrNull { it.uri == uri.toString() }
        if (existing != null) {
            selectTab(existing.id)
            return
        }
        viewModelScope.launch {
            runCatching {
                takePermissions(context, uri)
                val text = withContext(Dispatchers.IO) { FileUtils.readText(context.contentResolver, uri) }
                val name = FileUtils.displayName(context, uri)
                val tab = EditorTab(
                    title = name,
                    uri = uri.toString(),
                    value = TextFieldValue(text),
                    savedText = text
                )
                uiState = uiState.copy(tabs = uiState.tabs + tab, activeTabId = tab.id)
                addRecent(name, uri.toString())
                scheduleSessionSave()
            }.onFailure { error ->
                showMessage(error.message ?: "Could not open file")
            }
        }
    }

    fun openRecent(context: Context, uriString: String) {
        runCatching { Uri.parse(uriString) }
            .onSuccess { openUri(context, it) }
            .onFailure { showMessage("Could not open recent file") }
    }

    fun saveCurrent(context: Context, onSuccess: (() -> Unit)? = null) {
        val tab = uiState.activeTab ?: return
        val uri = tab.uri?.let(Uri::parse) ?: return
        viewModelScope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    FileUtils.writeUtf8(context.contentResolver, uri, tab.value.text)
                }
                replaceTab(tab.copy(savedText = tab.value.text))
                addRecent(tab.title, uri.toString())
                showMessage("Saved")
                scheduleSessionSave()
                onSuccess?.invoke()
            }.onFailure { error ->
                showMessage(error.message ?: "Could not save file")
            }
        }
    }

    fun saveAs(context: Context, uri: Uri, onSuccess: (() -> Unit)? = null) {
        val tab = uiState.activeTab ?: return
        viewModelScope.launch {
            runCatching {
                takePermissions(context, uri)
                withContext(Dispatchers.IO) {
                    FileUtils.writeUtf8(context.contentResolver, uri, tab.value.text)
                }
                val name = FileUtils.displayName(context, uri)
                val updated = tab.copy(
                    title = name,
                    uri = uri.toString(),
                    savedText = tab.value.text
                )
                replaceTab(updated)
                addRecent(name, uri.toString())
                showMessage("Saved")
                scheduleSessionSave()
                onSuccess?.invoke()
            }.onFailure { error ->
                showMessage(error.message ?: "Could not save file")
            }
        }
    }

    fun setFindVisible(visible: Boolean, replace: Boolean = false) {
        uiState = uiState.copy(findVisible = visible, replaceVisible = visible && replace)
    }

    fun setFindQuery(query: String) {
        uiState = uiState.copy(findQuery = query)
    }

    fun setReplaceQuery(query: String) {
        uiState = uiState.copy(replaceQuery = query)
    }

    fun setMatchCase(enabled: Boolean) {
        uiState = uiState.copy(matchCase = enabled)
    }

    fun findNext(backwards: Boolean = false) {
        val tab = uiState.activeTab ?: return
        val query = uiState.findQuery
        if (query.isEmpty()) return
        val text = tab.value.text
        if (text.isEmpty()) return

        val source = if (uiState.matchCase) text else text.lowercase()
        val needle = if (uiState.matchCase) query else query.lowercase()
        val selection = tab.value.selection

        val index = if (backwards) {
            val from = (selection.start - 1).coerceAtLeast(0)
            source.lastIndexOf(needle, from).takeIf { it >= 0 }
                ?: source.lastIndexOf(needle).takeIf { it >= 0 }
        } else {
            val from = selection.end.coerceAtMost(source.length)
            source.indexOf(needle, from).takeIf { it >= 0 }
                ?: source.indexOf(needle).takeIf { it >= 0 }
        } ?: return

        replaceTab(tab.copy(value = tab.value.copy(selection = TextRange(index, index + query.length))))
    }

    fun replaceCurrent() {
        val tab = uiState.activeTab ?: return
        val query = uiState.findQuery
        if (query.isEmpty()) return
        val sel = tab.value.selection
        if (sel.collapsed) {
            findNext()
            return
        }
        val selected = tab.value.text.substring(sel.min, sel.max)
        val matches = if (uiState.matchCase) selected == query else selected.equals(query, ignoreCase = true)
        if (!matches) {
            findNext()
            return
        }

        val newText = tab.value.text.replaceRange(sel.min, sel.max, uiState.replaceQuery)
        val cursor = sel.min + uiState.replaceQuery.length
        val newValue = TextFieldValue(newText, selection = TextRange(cursor))
        replaceTab(
            tab.copy(
                value = newValue,
                undoStack = (tab.undoStack + tab.value).takeLast(200),
                redoStack = emptyList()
            )
        )
        scheduleSessionSave()
        findNext()
    }

    fun replaceAll() {
        val tab = uiState.activeTab ?: return
        val query = uiState.findQuery
        if (query.isEmpty()) return
        val regex = Regex(
            Regex.escape(query),
            if (uiState.matchCase) emptySet() else setOf(RegexOption.IGNORE_CASE)
        )
        val newText = regex.replace(tab.value.text, uiState.replaceQuery)
        if (newText == tab.value.text) return
        val newValue = TextFieldValue(newText, selection = TextRange(0))
        replaceTab(
            tab.copy(
                value = newValue,
                undoStack = (tab.undoStack + tab.value).takeLast(200),
                redoStack = emptyList()
            )
        )
        scheduleSessionSave()
    }

    fun showSettings(show: Boolean) {
        uiState = uiState.copy(settingsVisible = show)
    }

    fun showRecent(show: Boolean) {
        uiState = uiState.copy(recentVisible = show)
    }

    fun setTheme(mode: ThemeMode) = updateSettings(uiState.settings.copy(themeMode = mode))
    fun setWordWrap(enabled: Boolean) = updateSettings(uiState.settings.copy(wordWrap = enabled))
    fun setLineNumbers(enabled: Boolean) = updateSettings(uiState.settings.copy(lineNumbers = enabled))
    fun setFontSize(size: Float) = updateSettings(uiState.settings.copy(fontSizeSp = size.coerceIn(10f, 32f)))
    fun setSessionRestore(enabled: Boolean) = updateSettings(uiState.settings.copy(sessionRestore = enabled))

    private fun updateSettings(settings: EditorSettings) {
        uiState = uiState.copy(settings = settings)
        settingsStore.saveSettings(settings)
        if (!settings.sessionRestore) sessionStore.clear() else scheduleSessionSave()
    }

    fun clearMessage() {
        uiState = uiState.copy(message = null)
    }

    fun handleExternalIntent(context: Context, intent: Intent?) {
        when (intent?.action) {
            Intent.ACTION_VIEW -> intent.data?.let { openUri(context, it) }
            Intent.ACTION_SEND -> {
                val sharedUri = intent.clipData?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.uri
                    ?: intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                if (sharedUri != null) {
                    openUri(context, sharedUri)
                } else {
                    val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
                    if (!sharedText.isNullOrEmpty()) {
                        val tab = EditorTab(title = "Shared text", value = TextFieldValue(sharedText))
                        uiState = uiState.copy(tabs = uiState.tabs + tab, activeTabId = tab.id)
                        scheduleSessionSave()
                    }
                }
            }
        }
    }

    private fun replaceTab(tab: EditorTab) {
        uiState = uiState.copy(tabs = uiState.tabs.map { if (it.id == tab.id) tab else it })
    }

    private fun nextUntitledNumber(): Int {
        val used = uiState.tabs.mapNotNull { tab ->
            Regex("^Untitled (\\d+)$").matchEntire(tab.title)?.groupValues?.getOrNull(1)?.toIntOrNull()
        }.toSet()
        var n = 1
        while (n in used) n++
        return n
    }

    private fun addRecent(title: String, uri: String) {
        val item = RecentFile(title, uri, System.currentTimeMillis())
        val updated = listOf(item) + uiState.recentFiles.filterNot { it.uri == uri }
        uiState = uiState.copy(recentFiles = updated.take(30))
        settingsStore.saveRecentFiles(uiState.recentFiles)
    }

    private fun takePermissions(context: Context, uri: Uri) {
        runCatching {
            context.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        }
    }

    private fun showMessage(message: String) {
        uiState = uiState.copy(message = message)
    }

    private fun scheduleSessionSave() {
        if (!uiState.settings.sessionRestore) return
        sessionSaveJob?.cancel()
        sessionSaveJob = viewModelScope.launch(Dispatchers.IO) {
            delay(250)
            val snapshot = uiState
            sessionStore.save(snapshot.tabs, snapshot.activeTabId)
        }
    }
}
