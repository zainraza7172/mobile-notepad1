# Jin Notepad currently has no custom shrinking rules.
