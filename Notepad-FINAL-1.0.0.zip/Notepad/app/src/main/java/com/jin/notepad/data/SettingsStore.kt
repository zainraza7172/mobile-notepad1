package com.jin.notepad.data

import android.content.Context
import com.jin.notepad.model.EditorSettings
import com.jin.notepad.model.LineEnding
import com.jin.notepad.model.RecentFile
import com.jin.notepad.model.TextEncoding
import com.jin.notepad.model.ThemeMode
import org.json.JSONArray
import org.json.JSONObject

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("jin_notepad_settings", Context.MODE_PRIVATE)

    fun loadSettings(): EditorSettings {
        fun <T : Enum<T>> enumOr(name: String?, fallback: T, values: Array<T>): T =
            values.firstOrNull { it.name == name } ?: fallback

        return EditorSettings(
            themeMode = enumOr(prefs.getString("theme", ThemeMode.SYSTEM.name), ThemeMode.SYSTEM, ThemeMode.entries.toTypedArray()),
            wordWrap = prefs.getBoolean("word_wrap", true),
            lineNumbers = prefs.getBoolean("line_numbers", false),
            fontSizeSp = prefs.getFloat("font_size", 17f),
            sessionRestore = prefs.getBoolean("session_restore", true),
            autoSave = prefs.getBoolean("auto_save", false),
            autoSaveDelaySeconds = prefs.getInt("auto_save_delay", 2).coerceIn(1, 30),
            showQuickToolbar = prefs.getBoolean("show_quick_toolbar", true),
            showStatusBar = prefs.getBoolean("show_status_bar", true),
            syntaxHighlighting = prefs.getBoolean("syntax_highlighting", true),
            tabWidth = prefs.getInt("tab_width", 4).coerceIn(2, 8),
            markdownPreview = prefs.getBoolean("markdown_preview", true),
            defaultEncoding = enumOr(prefs.getString("default_encoding", TextEncoding.UTF8.name), TextEncoding.UTF8, TextEncoding.entries.toTypedArray()),
            defaultLineEnding = enumOr(prefs.getString("default_line_ending", LineEnding.LF.name), LineEnding.LF, LineEnding.entries.toTypedArray()),
            cloudBackupTreeUri = prefs.getString("cloud_backup_tree_uri", null),
            cloudAutoBackup = prefs.getBoolean("cloud_auto_backup", true)
        )
    }

    fun saveSettings(settings: EditorSettings) {
        prefs.edit()
            .putString("theme", settings.themeMode.name)
            .putBoolean("word_wrap", settings.wordWrap)
            .putBoolean("line_numbers", settings.lineNumbers)
            .putFloat("font_size", settings.fontSizeSp)
            .putBoolean("session_restore", settings.sessionRestore)
            .putBoolean("auto_save", settings.autoSave)
            .putInt("auto_save_delay", settings.autoSaveDelaySeconds)
            .putBoolean("show_quick_toolbar", settings.showQuickToolbar)
            .putBoolean("show_status_bar", settings.showStatusBar)
            .putBoolean("syntax_highlighting", settings.syntaxHighlighting)
            .putInt("tab_width", settings.tabWidth)
            .putBoolean("markdown_preview", settings.markdownPreview)
            .putString("default_encoding", settings.defaultEncoding.name)
            .putString("default_line_ending", settings.defaultLineEnding.name)
            .putString("cloud_backup_tree_uri", settings.cloudBackupTreeUri)
            .putBoolean("cloud_auto_backup", settings.cloudAutoBackup)
            .apply()
    }

    fun loadLastCloudBackupAt(): Long? = prefs.getLong("last_cloud_backup_at", 0L).takeIf { it > 0L }

    fun saveLastCloudBackupAt(value: Long?) {
        val editor = prefs.edit()
        if (value == null) editor.remove("last_cloud_backup_at") else editor.putLong("last_cloud_backup_at", value)
        editor.apply()
    }

    fun loadRecentFiles(): List<RecentFile> {
        val raw = prefs.getString("recent_files", null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)
                    add(
                        RecentFile(
                            title = item.getString("title"),
                            uri = item.getString("uri"),
                            lastOpenedAt = item.optLong("lastOpenedAt", 0L),
                            pinned = item.optBoolean("pinned", false)
                        )
                    )
                }
            }.sortedWith(compareByDescending<RecentFile> { it.pinned }.thenByDescending { it.lastOpenedAt })
        }.getOrDefault(emptyList())
    }

    fun saveRecentFiles(files: List<RecentFile>) {
        val array = JSONArray()
        files.take(50).forEach { file ->
            array.put(
                JSONObject()
                    .put("title", file.title)
                    .put("uri", file.uri)
                    .put("lastOpenedAt", file.lastOpenedAt)
                    .put("pinned", file.pinned)
            )
        }
        prefs.edit().putString("recent_files", array.toString()).apply()
    }
}
