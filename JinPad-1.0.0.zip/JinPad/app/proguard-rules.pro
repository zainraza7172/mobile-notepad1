# JinPad currently needs no custom shrinking rules.
