# Notepad currently needs no custom shrinking rules.
