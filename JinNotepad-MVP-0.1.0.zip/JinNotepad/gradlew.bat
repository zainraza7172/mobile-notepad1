@echo off
setlocal
set GRADLE_VERSION=9.6.0
if "%GRADLE_USER_HOME%"=="" (
  set BASE=%USERPROFILE%\.gradle\jin-notepad-gradle
) else (
  set BASE=%GRADLE_USER_HOME%\jin-notepad-gradle
)
set DIST=%BASE%\gradle-%GRADLE_VERSION%
set ZIP=%BASE%\gradle-%GRADLE_VERSION%-bin.zip
set URL=https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip

if not exist "%DIST%\bin\gradle.bat" (
  if not exist "%BASE%" mkdir "%BASE%"
  if not exist "%ZIP%" powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri '%URL%' -OutFile '%ZIP%'"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Path '%ZIP%' -DestinationPath '%BASE%' -Force"
)

call "%DIST%\bin\gradle.bat" %*
endlocal
