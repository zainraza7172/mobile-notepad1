package com.jin.notepad.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jin.notepad.data.SessionStore
import com.jin.notepad.data.SettingsStore
import com.jin.notepad.model.EditorSettings
import com.jin.notepad.model.EditorTab
import com.jin.notepad.model.EditorUiState
import com.jin.notepad.model.LineEnding
import com.jin.notepad.model.RecentFile
import com.jin.notepad.model.TextEncoding
import com.jin.notepad.model.ThemeMode
import com.jin.notepad.util.DocumentTools
import com.jin.notepad.util.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class EditorViewModel(application: Application) : AndroidViewModel(application) {
    private val settingsStore = SettingsStore(application)
    private val sessionStore = SessionStore(application)
    private var sessionSaveJob: Job? = null
    private var autoSaveJob: Job? = null

    var uiState by mutableStateOf(initialState())
        private set

    private fun initialState(): EditorUiState {
        val settings = settingsStore.loadSettings()
        val recent = settingsStore.loadRecentFiles()
        if (settings.sessionRestore) {
            sessionStore.load()?.let { (tabs, activeId) ->
                val resolvedActive = activeId?.takeIf { id -> tabs.any { it.id == id } } ?: tabs.first().id
                return EditorUiState(
                    tabs = tabs,
                    activeTabId = resolvedActive,
                    settings = settings,
                    recentFiles = recent
                )
            }
        }
        val first = newBlankTab("txt", settings, 1)
        return EditorUiState(tabs = listOf(first), activeTabId = first.id, settings = settings, recentFiles = recent)
    }

    fun newTab(extension: String = "txt") {
        val cleanExt = extension.trim().trimStart('.').ifBlank { "txt" }.lowercase()
        val tab = newBlankTab(cleanExt, uiState.settings)
        uiState = uiState.copy(
            tabs = uiState.tabs + tab,
            activeTabId = tab.id,
            newFileVisible = false,
            markdownPreviewVisible = false
        )
        scheduleSessionSave()
    }

    fun selectTab(id: String) {
        if (uiState.tabs.any { it.id == id }) {
            uiState = uiState.copy(activeTabId = id, markdownPreviewVisible = false)
            scheduleSessionSave()
        }
    }

    fun closeTab(id: String) {
        val remaining = uiState.tabs.filterNot { it.id == id }
        if (remaining.isEmpty()) {
            val fresh = newBlankTab("txt", uiState.settings)
            uiState = uiState.copy(tabs = listOf(fresh), activeTabId = fresh.id, markdownPreviewVisible = false)
        } else {
            val oldIndex = uiState.tabs.indexOfFirst { it.id == id }.coerceAtLeast(0)
            val active = if (uiState.activeTabId == id) {
                remaining.getOrNull(oldIndex.coerceAtMost(remaining.lastIndex))?.id ?: remaining.last().id
            } else uiState.activeTabId
            uiState = uiState.copy(tabs = remaining, activeTabId = active, markdownPreviewVisible = false)
        }
        scheduleSessionSave()
    }

    fun closeOtherTabs(keepId: String) {
        val keep = uiState.tabs.firstOrNull { it.id == keepId } ?: return
        val dirtyOthers = uiState.tabs.filter { it.id != keepId && it.isDirty }
        val kept = listOf(keep) + dirtyOthers
        uiState = uiState.copy(tabs = kept.distinctBy { it.id }, activeTabId = keep.id)
        if (dirtyOthers.isNotEmpty()) showMessage("${dirtyOthers.size} unsaved tab(s) kept open")
        scheduleSessionSave()
    }

    fun closeAllCleanTabs() {
        val dirty = uiState.tabs.filter { it.isDirty }
        if (dirty.isEmpty()) {
            val fresh = newBlankTab("txt", uiState.settings)
            uiState = uiState.copy(tabs = listOf(fresh), activeTabId = fresh.id)
        } else {
            uiState = uiState.copy(tabs = dirty, activeTabId = dirty.first().id)
            showMessage("Unsaved tabs were kept open")
        }
        scheduleSessionSave()
    }

    fun selectRelativeTab(delta: Int) {
        if (uiState.tabs.isEmpty()) return
        val current = uiState.tabs.indexOfFirst { it.id == uiState.activeTabId }.coerceAtLeast(0)
        val next = (current + delta).mod(uiState.tabs.size)
        selectTab(uiState.tabs[next].id)
    }

    fun moveTab(id: String, direction: Int) {
        val from = uiState.tabs.indexOfFirst { it.id == id }
        if (from < 0) return
        val to = (from + direction).coerceIn(0, uiState.tabs.lastIndex)
        if (from == to) return
        val mutable = uiState.tabs.toMutableList()
        val item = mutable.removeAt(from)
        mutable.add(to, item)
        uiState = uiState.copy(tabs = mutable)
        scheduleSessionSave()
    }

    fun updateText(value: TextFieldValue) {
        val active = uiState.activeTab ?: return
        val updated = if (value.text != active.value.text) {
            active.copy(
                value = value,
                undoStack = (active.undoStack + active.value).takeLast(250),
                redoStack = emptyList()
            )
        } else active.copy(value = value)
        replaceTab(updated)
        scheduleSessionSave()
        if (value.text != active.value.text) scheduleAutoSave()
    }

    fun undo() {
        val tab = uiState.activeTab ?: return
        val previous = tab.undoStack.lastOrNull() ?: return
        replaceTab(tab.copy(
            value = previous,
            undoStack = tab.undoStack.dropLast(1),
            redoStack = (tab.redoStack + tab.value).takeLast(250)
        ))
        scheduleSessionSave(); scheduleAutoSave()
    }

    fun redo() {
        val tab = uiState.activeTab ?: return
        val next = tab.redoStack.lastOrNull() ?: return
        replaceTab(tab.copy(
            value = next,
            redoStack = tab.redoStack.dropLast(1),
            undoStack = (tab.undoStack + tab.value).takeLast(250)
        ))
        scheduleSessionSave(); scheduleAutoSave()
    }

    fun selectAll() {
        val tab = uiState.activeTab ?: return
        replaceTab(tab.copy(value = tab.value.copy(selection = TextRange(0, tab.value.text.length))))
    }

    fun insertText(text: String) {
        val tab = uiState.activeTab ?: return
        val sel = tab.value.selection
        val start = sel.min
        val end = sel.max
        val newText = tab.value.text.replaceRange(start, end, text)
        val newCursor = start + text.length
        applyTextChange(tab, TextFieldValue(newText, selection = TextRange(newCursor)))
    }

    fun indentSelection() {
        transformSelectedLines(unindent = false)
    }

    fun unindentSelection() {
        transformSelectedLines(unindent = true)
    }

    private fun transformSelectedLines(unindent: Boolean) {
        val tab = uiState.activeTab ?: return
        val text = tab.value.text
        val sel = tab.value.selection
        val lineStart = text.lastIndexOf('\n', (sel.min - 1).coerceAtLeast(0)).let { if (it < 0) 0 else it + 1 }
        val lineEndCandidate = text.indexOf('\n', sel.max)
        val lineEnd = if (lineEndCandidate < 0) text.length else lineEndCandidate
        val block = text.substring(lineStart, lineEnd)
        val spaces = " ".repeat(uiState.settings.tabWidth)
        val transformed = if (unindent) {
            block.lineSequence().joinToString("\n") { line ->
                when {
                    line.startsWith("\t") -> line.drop(1)
                    line.startsWith(spaces) -> line.drop(spaces.length)
                    else -> line.dropWhileIndexed(uiState.settings.tabWidth) { it == ' ' }
                }
            }
        } else {
            block.lineSequence().joinToString("\n") { spaces + it }
        }
        val newText = text.replaceRange(lineStart, lineEnd, transformed)
        val delta = transformed.length - block.length
        val newSel = TextRange(lineStart, (lineEnd + delta).coerceAtLeast(lineStart))
        applyTextChange(tab, TextFieldValue(newText, selection = newSel))
    }

    private fun String.dropWhileIndexed(limit: Int, predicate: (Char) -> Boolean): String {
        var count = 0
        while (count < length && count < limit && predicate(this[count])) count++
        return drop(count)
    }

    fun duplicateLine() {
        val tab = uiState.activeTab ?: return
        val text = tab.value.text
        val cursor = tab.value.selection.start.coerceIn(0, text.length)
        val start = text.lastIndexOf('\n', (cursor - 1).coerceAtLeast(0)).let { if (it < 0) 0 else it + 1 }
        val endIndex = text.indexOf('\n', cursor)
        val end = if (endIndex < 0) text.length else endIndex
        val line = text.substring(start, end)
        val insertion = "\n$line"
        val newText = text.substring(0, end) + insertion + text.substring(end)
        val newCursor = (cursor + insertion.length).coerceAtMost(newText.length)
        applyTextChange(tab, TextFieldValue(newText, selection = TextRange(newCursor)))
    }

    fun goToLine(lineNumber: Int) {
        val tab = uiState.activeTab ?: return
        val target = lineNumber.coerceAtLeast(1)
        var current = 1
        var offset = 0
        while (current < target) {
            val next = tab.value.text.indexOf('\n', offset)
            if (next < 0) break
            offset = next + 1
            current++
        }
        replaceTab(tab.copy(value = tab.value.copy(selection = TextRange(offset))))
        uiState = uiState.copy(goToLineVisible = false)
    }

    fun formatDocument() {
        val tab = uiState.activeTab ?: return
        runCatching { DocumentTools.format(tab.title, tab.value.text) }
            .onSuccess { formatted ->
                if (formatted == tab.value.text) {
                    showMessage("Formatting is available for JSON and XML")
                } else {
                    applyTextChange(tab, TextFieldValue(formatted, selection = TextRange(0)))
                    showMessage("Document formatted")
                }
            }
            .onFailure { showMessage(it.message ?: "Could not format document") }
    }

    fun openUri(context: Context, uri: Uri) {
        uiState.tabs.firstOrNull { it.uri == uri.toString() }?.let { selectTab(it.id); return }
        viewModelScope.launch {
            runCatching {
                takePermissions(context, uri)
                val result = withContext(Dispatchers.IO) { FileUtils.readText(context.contentResolver, uri) }
                val name = FileUtils.displayName(context, uri)
                EditorTab(
                    title = name,
                    uri = uri.toString(),
                    value = TextFieldValue(result.text),
                    savedText = result.text,
                    encoding = result.encoding,
                    lineEnding = result.lineEnding
                )
            }.onSuccess { tab ->
                uiState = uiState.copy(tabs = uiState.tabs + tab, activeTabId = tab.id, markdownPreviewVisible = false)
                addRecent(tab.title, uri.toString())
                if (tab.isLargeFile) showMessage("Large file mode: syntax highlighting is limited")
                scheduleSessionSave()
            }.onFailure { error -> showMessage(error.message ?: "Could not open file") }
        }
    }

    fun openRecent(context: Context, uriString: String) {
        runCatching { Uri.parse(uriString) }
            .onSuccess { openUri(context, it) }
            .onFailure { showMessage("Could not open recent file") }
    }

    fun saveCurrent(context: Context, onSuccess: (() -> Unit)? = null) {
        val tab = uiState.activeTab ?: return
        val uri = tab.uri?.let(Uri::parse) ?: return
        viewModelScope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    FileUtils.writeText(context.contentResolver, uri, tab.value.text, tab.encoding, tab.lineEnding)
                }
            }.onSuccess {
                val current = uiState.tabs.firstOrNull { it.id == tab.id } ?: tab
                replaceTab(current.copy(savedText = current.value.text))
                addRecent(tab.title, uri.toString())
                showMessage("Saved")
                scheduleSessionSave()
                onSuccess?.invoke()
            }.onFailure { error -> showMessage(error.message ?: "Could not save file") }
        }
    }

    fun saveAs(context: Context, uri: Uri, onSuccess: (() -> Unit)? = null) {
        val tab = uiState.activeTab ?: return
        viewModelScope.launch {
            runCatching {
                takePermissions(context, uri)
                withContext(Dispatchers.IO) {
                    FileUtils.writeText(context.contentResolver, uri, tab.value.text, tab.encoding, tab.lineEnding)
                }
                FileUtils.displayName(context, uri)
            }.onSuccess { name ->
                val current = uiState.tabs.firstOrNull { it.id == tab.id } ?: tab
                replaceTab(current.copy(title = name, uri = uri.toString(), savedText = current.value.text))
                addRecent(name, uri.toString())
                showMessage("Saved")
                scheduleSessionSave()
                onSuccess?.invoke()
            }.onFailure { error -> showMessage(error.message ?: "Could not save file") }
        }
    }

    fun setFindVisible(visible: Boolean, replace: Boolean = false) {
        uiState = uiState.copy(findVisible = visible, replaceVisible = visible && replace)
    }
    fun setFindQuery(query: String) { uiState = uiState.copy(findQuery = query) }
    fun setReplaceQuery(query: String) { uiState = uiState.copy(replaceQuery = query) }
    fun setMatchCase(enabled: Boolean) { uiState = uiState.copy(matchCase = enabled) }
    fun setWholeWord(enabled: Boolean) { uiState = uiState.copy(wholeWord = enabled) }
    fun setRegexSearch(enabled: Boolean) { uiState = uiState.copy(regexSearch = enabled) }

    private fun searchRegex(): Regex? {
        val query = uiState.findQuery
        if (query.isEmpty()) return null
        val pattern = if (uiState.regexSearch) query else Regex.escape(query)
        val wrapped = if (uiState.wholeWord) "(?<![A-Za-z0-9_])(?:$pattern)(?![A-Za-z0-9_])" else pattern
        val options = if (uiState.matchCase) emptySet() else setOf(RegexOption.IGNORE_CASE)
        return runCatching { Regex(wrapped, options) }.getOrElse {
            showMessage("Invalid regular expression")
            null
        }
    }

    fun findNext(backwards: Boolean = false) {
        val tab = uiState.activeTab ?: return
        val regex = searchRegex() ?: return
        val text = tab.value.text
        if (text.isEmpty()) return
        val sel = tab.value.selection
        val matches = regex.findAll(text).toList()
        if (matches.isEmpty()) { showMessage("No matches"); return }
        val match = if (backwards) {
            matches.lastOrNull { it.range.last < sel.min } ?: matches.last()
        } else {
            matches.firstOrNull { it.range.first >= sel.max } ?: matches.first()
        }
        replaceTab(tab.copy(value = tab.value.copy(selection = TextRange(match.range.first, match.range.last + 1))))
    }

    fun replaceCurrent() {
        val tab = uiState.activeTab ?: return
        val regex = searchRegex() ?: return
        val sel = tab.value.selection
        if (sel.collapsed) { findNext(); return }
        val selected = tab.value.text.substring(sel.min, sel.max)
        if (!regex.matches(selected)) { findNext(); return }
        val replacement = if (uiState.regexSearch) {
            runCatching { regex.replaceFirst(selected, uiState.replaceQuery) }.getOrDefault(uiState.replaceQuery)
        } else uiState.replaceQuery
        val newText = tab.value.text.replaceRange(sel.min, sel.max, replacement)
        applyTextChange(tab, TextFieldValue(newText, selection = TextRange(sel.min + replacement.length)))
        findNext()
    }

    fun replaceAll() {
        val tab = uiState.activeTab ?: return
        val regex = searchRegex() ?: return
        val newText = regex.replace(tab.value.text, uiState.replaceQuery)
        if (newText == tab.value.text) { showMessage("No matches"); return }
        applyTextChange(tab, TextFieldValue(newText, selection = TextRange(0)))
    }

    fun showSettings(show: Boolean) { uiState = uiState.copy(settingsVisible = show) }
    fun showRecent(show: Boolean) { uiState = uiState.copy(recentVisible = show) }
    fun showGoToLine(show: Boolean) { uiState = uiState.copy(goToLineVisible = show) }
    fun showFileInfo(show: Boolean) { uiState = uiState.copy(fileInfoVisible = show) }
    fun showNewFile(show: Boolean) { uiState = uiState.copy(newFileVisible = show) }
    fun setMarkdownPreviewVisible(show: Boolean) { uiState = uiState.copy(markdownPreviewVisible = show) }

    fun setTheme(mode: ThemeMode) = updateSettings(uiState.settings.copy(themeMode = mode))
    fun setWordWrap(enabled: Boolean) = updateSettings(uiState.settings.copy(wordWrap = enabled))
    fun setLineNumbers(enabled: Boolean) = updateSettings(uiState.settings.copy(lineNumbers = enabled))
    fun setFontSize(size: Float) = updateSettings(uiState.settings.copy(fontSizeSp = size.coerceIn(10f, 34f)))
    fun setSessionRestore(enabled: Boolean) = updateSettings(uiState.settings.copy(sessionRestore = enabled))
    fun setAutoSave(enabled: Boolean) = updateSettings(uiState.settings.copy(autoSave = enabled))
    fun setAutoSaveDelay(seconds: Int) = updateSettings(uiState.settings.copy(autoSaveDelaySeconds = seconds.coerceIn(1, 30)))
    fun setShowQuickToolbar(enabled: Boolean) = updateSettings(uiState.settings.copy(showQuickToolbar = enabled))
    fun setShowStatusBar(enabled: Boolean) = updateSettings(uiState.settings.copy(showStatusBar = enabled))
    fun setSyntaxHighlighting(enabled: Boolean) = updateSettings(uiState.settings.copy(syntaxHighlighting = enabled))
    fun setTabWidth(width: Int) = updateSettings(uiState.settings.copy(tabWidth = width.coerceIn(2, 8)))
    fun setMarkdownPreview(enabled: Boolean) = updateSettings(uiState.settings.copy(markdownPreview = enabled))
    fun setDefaultEncoding(value: TextEncoding) = updateSettings(uiState.settings.copy(defaultEncoding = value))
    fun setDefaultLineEnding(value: LineEnding) = updateSettings(uiState.settings.copy(defaultLineEnding = value))

    fun setCurrentEncoding(value: TextEncoding) {
        uiState.activeTab?.let { replaceTab(it.copy(encoding = value)) }
        scheduleSessionSave()
    }
    fun setCurrentLineEnding(value: LineEnding) {
        uiState.activeTab?.let { replaceTab(it.copy(lineEnding = value)) }
        scheduleSessionSave()
    }

    fun toggleRecentPin(uri: String) {
        val updated = uiState.recentFiles.map { if (it.uri == uri) it.copy(pinned = !it.pinned) else it }
            .sortedWith(compareByDescending<RecentFile> { it.pinned }.thenByDescending { it.lastOpenedAt })
        uiState = uiState.copy(recentFiles = updated)
        settingsStore.saveRecentFiles(updated)
    }

    fun removeRecent(uri: String) {
        val updated = uiState.recentFiles.filterNot { it.uri == uri }
        uiState = uiState.copy(recentFiles = updated)
        settingsStore.saveRecentFiles(updated)
    }

    fun clearRecent() {
        val pinned = uiState.recentFiles.filter { it.pinned }
        uiState = uiState.copy(recentFiles = pinned)
        settingsStore.saveRecentFiles(pinned)
    }

    private fun updateSettings(settings: EditorSettings) {
        uiState = uiState.copy(settings = settings)
        settingsStore.saveSettings(settings)
        if (!settings.sessionRestore) sessionStore.clear() else scheduleSessionSave()
    }

    private fun scheduleAutoSave() {
        if (!uiState.settings.autoSave) return
        val tab = uiState.activeTab ?: return
        if (tab.uri == null || !tab.isDirty) return
        autoSaveJob?.cancel()
        autoSaveJob = viewModelScope.launch {
            delay(uiState.settings.autoSaveDelaySeconds * 1000L)
            val latest = uiState.tabs.firstOrNull { it.id == tab.id } ?: return@launch
            if (latest.uri == null || !latest.isDirty) return@launch
            runCatching {
                val uri = Uri.parse(latest.uri)
                withContext(Dispatchers.IO) {
                    FileUtils.writeText(getApplication<Application>().contentResolver, uri, latest.value.text, latest.encoding, latest.lineEnding)
                }
            }.onSuccess {
                val current = uiState.tabs.firstOrNull { it.id == latest.id }
                if (current != null && current.value.text == latest.value.text) {
                    replaceTab(current.copy(savedText = current.value.text))
                    scheduleSessionSave()
                }
            }
        }
    }

    fun clearMessage() { uiState = uiState.copy(message = null) }

    fun handleExternalIntent(context: Context, intent: Intent?) {
        when (intent?.action) {
            Intent.ACTION_VIEW -> intent.data?.let { openUri(context, it) }
            Intent.ACTION_SEND -> {
                val sharedUri = intent.clipData?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.uri
                    ?: intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                if (sharedUri != null) openUri(context, sharedUri)
                else intent.getStringExtra(Intent.EXTRA_TEXT)?.takeIf { it.isNotEmpty() }?.let { sharedText ->
                    val tab = EditorTab(
                        title = "Shared text.txt",
                        value = TextFieldValue(sharedText),
                        encoding = uiState.settings.defaultEncoding,
                        lineEnding = uiState.settings.defaultLineEnding
                    )
                    uiState = uiState.copy(tabs = uiState.tabs + tab, activeTabId = tab.id)
                    scheduleSessionSave()
                }
            }
        }
    }

    private fun applyTextChange(tab: EditorTab, value: TextFieldValue) {
        replaceTab(tab.copy(
            value = value,
            undoStack = (tab.undoStack + tab.value).takeLast(250),
            redoStack = emptyList()
        ))
        scheduleSessionSave(); scheduleAutoSave()
    }

    private fun replaceTab(tab: EditorTab) {
        uiState = uiState.copy(tabs = uiState.tabs.map { if (it.id == tab.id) tab else it })
    }

    private fun newBlankTab(extension: String, settings: EditorSettings, number: Int = nextUntitledNumber()): EditorTab {
        val n = number
        return EditorTab(
            title = "Untitled $n.$extension",
            encoding = settings.defaultEncoding,
            lineEnding = settings.defaultLineEnding
        )
    }

    private fun nextUntitledNumber(): Int {
        val used = uiState.tabs.mapNotNull { tab ->
            Regex("^Untitled (\\d+)(?:\\.[^.]+)?$").matchEntire(tab.title)?.groupValues?.getOrNull(1)?.toIntOrNull()
        }.toSet()
        var n = 1
        while (n in used) n++
        return n
    }

    private fun addRecent(title: String, uri: String) {
        val existing = uiState.recentFiles.firstOrNull { it.uri == uri }
        val item = RecentFile(title, uri, System.currentTimeMillis(), pinned = existing?.pinned == true)
        val updated = (listOf(item) + uiState.recentFiles.filterNot { it.uri == uri })
            .sortedWith(compareByDescending<RecentFile> { it.pinned }.thenByDescending { it.lastOpenedAt })
            .take(50)
        uiState = uiState.copy(recentFiles = updated)
        settingsStore.saveRecentFiles(updated)
    }

    private fun takePermissions(context: Context, uri: Uri) {
        runCatching {
            context.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        }
    }

    private fun showMessage(message: String) { uiState = uiState.copy(message = message) }

    private fun scheduleSessionSave() {
        if (!uiState.settings.sessionRestore) return
        sessionSaveJob?.cancel()
        sessionSaveJob = viewModelScope.launch(Dispatchers.IO) {
            delay(250)
            val snapshot = uiState
            sessionStore.save(snapshot.tabs, snapshot.activeTabId)
        }
    }

}
