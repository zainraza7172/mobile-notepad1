package com.jin.notepad.util

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation

class CodeVisualTransformation(
    private val extension: String,
    private val colors: SyntaxColors
) : VisualTransformation {

    override fun filter(text: AnnotatedString): TransformedText {
        if (text.text.length > 300_000) return TransformedText(text, OffsetMapping.Identity)
        val builder = AnnotatedString.Builder(text.text)
        val source = text.text

        fun style(regex: Regex, span: SpanStyle) {
            regex.findAll(source).forEach { match ->
                val start = match.range.first.coerceAtLeast(0)
                val end = (match.range.last + 1).coerceAtMost(source.length)
                if (start < end) builder.addStyle(span, start, end)
            }
        }

        val stringStyle = SpanStyle(color = colors.string)
        val commentStyle = SpanStyle(color = colors.comment)
        val numberStyle = SpanStyle(color = colors.number)
        val keywordStyle = SpanStyle(color = colors.keyword, fontWeight = FontWeight.SemiBold)
        val tagStyle = SpanStyle(color = colors.tag)
        val propertyStyle = SpanStyle(color = colors.property)

        when (extension.lowercase()) {
            "json" -> {
                style(Regex("\\\"(?:\\\\.|[^\\\"\\\\])*\\\"(?=\\s*:)") , propertyStyle)
                style(Regex("\\\"(?:\\\\.|[^\\\"\\\\])*\\\"") , stringStyle)
                style(Regex("(?<![\\w.])-?\\b\\d+(?:\\.\\d+)?(?:[eE][+-]?\\d+)?\\b"), numberStyle)
                style(Regex("\\b(true|false|null)\\b"), keywordStyle)
            }
            "xml", "html", "htm" -> {
                style(Regex("<!--[\\s\\S]*?-->|//.*$", setOf(RegexOption.MULTILINE)), commentStyle)
                style(Regex("</?[A-Za-z][^>]*?>"), tagStyle)
                style(Regex("\\b[A-Za-z_:][-A-Za-z0-9_:.]*(?=\\s*=)"), propertyStyle)
                style(Regex("\\\"[^\\\"]*\\\"|'[^']*'"), stringStyle)
            }
            "css" -> {
                style(Regex("/\\*[\\s\\S]*?\\*/"), commentStyle)
                style(Regex("#[0-9A-Fa-f]{3,8}\\b|\\b\\d+(?:\\.\\d+)?(?:px|em|rem|%|vh|vw|s|ms)?\\b"), numberStyle)
                style(Regex("[A-Za-z-]+(?=\\s*:)") , propertyStyle)
            }
            "py" -> {
                style(Regex("#.*$", RegexOption.MULTILINE), commentStyle)
                style(Regex("\\\"\\\"\\\"[\\s\\S]*?\\\"\\\"\\\"|'''[\\s\\S]*?'''|\\\"(?:\\\\.|[^\\\"\\\\])*\\\"|'(?:\\\\.|[^'\\\\])*'"), stringStyle)
                style(Regex("\\b(def|class|return|if|elif|else|for|while|try|except|finally|with|as|import|from|pass|break|continue|lambda|yield|async|await|in|is|not|and|or|True|False|None|global|nonlocal|assert|del|raise)\\b"), keywordStyle)
                style(Regex("\\b\\d+(?:\\.\\d+)?\\b"), numberStyle)
            }
            "kt", "kts", "java", "js", "ts", "c", "cpp", "h", "hpp", "cs", "sh", "sql" -> {
                style(Regex("//.*$|/\\*[\\s\\S]*?\\*/", setOf(RegexOption.MULTILINE)), commentStyle)
                style(Regex("\\\"(?:\\\\.|[^\\\"\\\\])*\\\"|'(?:\\\\.|[^'\\\\])*'"), stringStyle)
                style(Regex("\\b(class|interface|object|fun|val|var|const|final|public|private|protected|internal|static|void|int|long|double|float|boolean|char|string|String|new|return|if|else|for|while|do|when|switch|case|break|continue|try|catch|finally|throw|throws|import|package|extends|implements|this|super|null|true|false|async|await|let|const|function|export|default|typeof|instanceof|in|is|as|data|sealed|enum|override|open|suspend|SELECT|FROM|WHERE|INSERT|UPDATE|DELETE|CREATE|TABLE|JOIN|ON|GROUP|ORDER|BY|LIMIT)\\b", RegexOption.IGNORE_CASE), keywordStyle)
                style(Regex("\\b\\d+(?:\\.\\d+)?[fFdDlL]?\\b"), numberStyle)
            }
            "yaml", "yml" -> {
                style(Regex("#.*$", RegexOption.MULTILINE), commentStyle)
                style(Regex("^[ \\t-]*[A-Za-z0-9_.-]+(?=\\s*:)", RegexOption.MULTILINE), propertyStyle)
                style(Regex("\\\"(?:\\\\.|[^\\\"\\\\])*\\\"|'[^']*'"), stringStyle)
                style(Regex("\\b(true|false|null|yes|no)\\b", RegexOption.IGNORE_CASE), keywordStyle)
            }
        }
        return TransformedText(builder.toAnnotatedString(), OffsetMapping.Identity)
    }
}

data class SyntaxColors(
    val keyword: Color,
    val string: Color,
    val comment: Color,
    val number: Color,
    val tag: Color,
    val property: Color
)
