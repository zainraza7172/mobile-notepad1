package com.jin.notepad.util

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.jin.notepad.model.LineEnding
import com.jin.notepad.model.TextEncoding
import java.io.ByteArrayOutputStream
import java.nio.charset.Charset

object FileUtils {
    data class ReadResult(
        val text: String,
        val encoding: TextEncoding,
        val lineEnding: LineEnding
    )

    fun displayName(context: Context, uri: Uri): String {
        val cursor = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val index = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) return it.getString(index) ?: "Untitled.txt"
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "Untitled.txt"
    }

    fun fileSize(context: Context, uri: Uri): Long? {
        val cursor = context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val index = it.getColumnIndex(OpenableColumns.SIZE)
                if (index >= 0 && !it.isNull(index)) return it.getLong(index)
            }
        }
        return null
    }

    fun readText(resolver: ContentResolver, uri: Uri): ReadResult {
        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() }
            ?: error("Unable to open file")

        val (encoding, decoded) = when {
            bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte() ->
                TextEncoding.UTF8_BOM to bytes.copyOfRange(3, bytes.size).toString(Charsets.UTF_8)
            bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte() ->
                TextEncoding.UTF16_LE to bytes.copyOfRange(2, bytes.size).toString(Charset.forName("UTF-16LE"))
            bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte() ->
                TextEncoding.UTF16_BE to bytes.copyOfRange(2, bytes.size).toString(Charset.forName("UTF-16BE"))
            else -> TextEncoding.UTF8 to bytes.toString(Charsets.UTF_8)
        }

        val lineEnding = when {
            decoded.contains("\r\n") -> LineEnding.CRLF
            decoded.contains('\r') -> LineEnding.CR
            else -> LineEnding.LF
        }
        val normalized = decoded.replace("\r\n", "\n").replace('\r', '\n')
        return ReadResult(normalized, encoding, lineEnding)
    }

    fun writeText(
        resolver: ContentResolver,
        uri: Uri,
        text: String,
        encoding: TextEncoding,
        lineEnding: LineEnding
    ) {
        val newline = when (lineEnding) {
            LineEnding.LF -> "\n"
            LineEnding.CRLF -> "\r\n"
            LineEnding.CR -> "\r"
        }
        val normalized = text.replace("\r\n", "\n").replace('\r', '\n')
        val converted = if (newline == "\n") normalized else normalized.replace("\n", newline)
        val bytes = when (encoding) {
            TextEncoding.UTF8 -> converted.toByteArray(Charsets.UTF_8)
            TextEncoding.UTF8_BOM -> byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) + converted.toByteArray(Charsets.UTF_8)
            TextEncoding.UTF16_LE -> byteArrayOf(0xFF.toByte(), 0xFE.toByte()) + converted.toByteArray(Charset.forName("UTF-16LE"))
            TextEncoding.UTF16_BE -> byteArrayOf(0xFE.toByte(), 0xFF.toByte()) + converted.toByteArray(Charset.forName("UTF-16BE"))
        }
        resolver.openOutputStream(uri, "wt")?.use { stream -> stream.write(bytes) }
            ?: error("Unable to save file")
    }

    fun estimatedBytes(text: String, encoding: TextEncoding): Int {
        return when (encoding) {
            TextEncoding.UTF8, TextEncoding.UTF8_BOM -> text.toByteArray(Charsets.UTF_8).size + if (encoding == TextEncoding.UTF8_BOM) 3 else 0
            TextEncoding.UTF16_LE, TextEncoding.UTF16_BE -> text.length * 2 + 2
        }
    }
}
