package com.jin.notepad.data

import android.content.Context
import android.net.Uri
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.documentfile.provider.DocumentFile
import com.jin.notepad.model.EditorSettings
import com.jin.notepad.model.EditorTab
import com.jin.notepad.model.LineEnding
import com.jin.notepad.model.RecentFile
import com.jin.notepad.model.TextEncoding
import com.jin.notepad.model.ThemeMode
import org.json.JSONArray
import org.json.JSONObject

object CloudBackupStore {
    const val FILE_NAME = "Notepad-Backup.json"
    private const val FORMAT_VERSION = 1

    data class BackupData(
        val settings: EditorSettings,
        val tabs: List<EditorTab>,
        val activeTabId: String?,
        val recentFiles: List<RecentFile>,
        val createdAt: Long
    )

    fun hasBackup(context: Context, treeUri: Uri): Boolean =
        root(context, treeUri).findFile(FILE_NAME)?.isFile == true

    fun writeBackup(
        context: Context,
        treeUri: Uri,
        settings: EditorSettings,
        tabs: List<EditorTab>,
        activeTabId: String,
        recentFiles: List<RecentFile>
    ): Long {
        val root = root(context, treeUri)
        val target = root.findFile(FILE_NAME)
            ?: root.createFile("application/json", FILE_NAME)
            ?: error("Could not create backup file")

        val createdAt = System.currentTimeMillis()
        val json = JSONObject()
            .put("formatVersion", FORMAT_VERSION)
            .put("createdAt", createdAt)
            .put("activeTabId", activeTabId)
            .put("settings", settingsToJson(settings))
            .put("tabs", tabsToJson(tabs))
            .put("recentFiles", recentToJson(recentFiles))
            .toString()

        context.contentResolver.openOutputStream(target.uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use {
            it.write(json)
        } ?: error("Could not write backup file")
        return createdAt
    }

    fun readBackup(context: Context, treeUri: Uri): BackupData {
        val root = root(context, treeUri)
        val file = root.findFile(FILE_NAME) ?: error("No Notepad backup found in this folder")
        val text = context.contentResolver.openInputStream(file.uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
            ?: error("Could not read backup file")
        val json = JSONObject(text)
        if (json.optInt("formatVersion", 0) > FORMAT_VERSION) error("This backup was created by a newer Notepad version")

        val settings = settingsFromJson(json.optJSONObject("settings") ?: JSONObject())
        val tabs = tabsFromJson(json.optJSONArray("tabs") ?: JSONArray())
        if (tabs.isEmpty()) error("Backup has no restorable tabs")
        val recent = recentFromJson(json.optJSONArray("recentFiles") ?: JSONArray())
        return BackupData(
            settings = settings,
            tabs = tabs,
            activeTabId = json.optString("activeTabId").takeIf { it.isNotBlank() },
            recentFiles = recent,
            createdAt = json.optLong("createdAt", 0L)
        )
    }

    fun folderName(context: Context, treeUri: Uri): String =
        runCatching { root(context, treeUri).name }.getOrNull()?.takeIf { !it.isNullOrBlank() } ?: "Cloud folder"

    private fun root(context: Context, treeUri: Uri): DocumentFile =
        DocumentFile.fromTreeUri(context, treeUri) ?: error("Could not access selected folder")

    private fun settingsToJson(s: EditorSettings) = JSONObject()
        .put("themeMode", s.themeMode.name)
        .put("wordWrap", s.wordWrap)
        .put("lineNumbers", s.lineNumbers)
        .put("fontSizeSp", s.fontSizeSp.toDouble())
        .put("sessionRestore", s.sessionRestore)
        .put("autoSave", s.autoSave)
        .put("autoSaveDelaySeconds", s.autoSaveDelaySeconds)
        .put("showQuickToolbar", s.showQuickToolbar)
        .put("showStatusBar", s.showStatusBar)
        .put("syntaxHighlighting", s.syntaxHighlighting)
        .put("tabWidth", s.tabWidth)
        .put("markdownPreview", s.markdownPreview)
        .put("defaultEncoding", s.defaultEncoding.name)
        .put("defaultLineEnding", s.defaultLineEnding.name)
        .put("cloudAutoBackup", s.cloudAutoBackup)

    private fun settingsFromJson(j: JSONObject): EditorSettings = EditorSettings(
        themeMode = enumValue(j.optString("themeMode"), ThemeMode.SYSTEM),
        wordWrap = j.optBoolean("wordWrap", true),
        lineNumbers = j.optBoolean("lineNumbers", false),
        fontSizeSp = j.optDouble("fontSizeSp", 17.0).toFloat().coerceIn(10f, 34f),
        sessionRestore = j.optBoolean("sessionRestore", true),
        autoSave = j.optBoolean("autoSave", false),
        autoSaveDelaySeconds = j.optInt("autoSaveDelaySeconds", 2).coerceIn(1, 30),
        showQuickToolbar = j.optBoolean("showQuickToolbar", true),
        showStatusBar = j.optBoolean("showStatusBar", true),
        syntaxHighlighting = j.optBoolean("syntaxHighlighting", true),
        tabWidth = j.optInt("tabWidth", 4).coerceIn(2, 8),
        markdownPreview = j.optBoolean("markdownPreview", true),
        defaultEncoding = enumValue(j.optString("defaultEncoding"), TextEncoding.UTF8),
        defaultLineEnding = enumValue(j.optString("defaultLineEnding"), LineEnding.LF),
        cloudAutoBackup = j.optBoolean("cloudAutoBackup", true)
    )

    private fun tabsToJson(tabs: List<EditorTab>): JSONArray = JSONArray().apply {
        tabs.forEach { tab ->
            put(JSONObject()
                .put("id", tab.id)
                .put("title", tab.title)
                .put("text", tab.value.text)
                .put("selectionStart", tab.value.selection.start)
                .put("selectionEnd", tab.value.selection.end)
                .put("encoding", tab.encoding.name)
                .put("lineEnding", tab.lineEnding.name)
            )
        }
    }

    private fun tabsFromJson(array: JSONArray): List<EditorTab> = buildList {
        for (i in 0 until array.length()) {
            val item = array.getJSONObject(i)
            val text = item.optString("text", "")
            val start = item.optInt("selectionStart", 0).coerceIn(0, text.length)
            val end = item.optInt("selectionEnd", start).coerceIn(0, text.length)
            add(EditorTab(
                id = item.optString("id").takeIf { it.isNotBlank() } ?: java.util.UUID.randomUUID().toString(),
                title = item.optString("title", "Restored.txt"),
                uri = null,
                value = TextFieldValue(text, TextRange(start, end)),
                savedText = "",
                encoding = enumValue(item.optString("encoding"), TextEncoding.UTF8),
                lineEnding = enumValue(item.optString("lineEnding"), LineEnding.LF)
            ))
        }
    }

    private fun recentToJson(files: List<RecentFile>): JSONArray = JSONArray().apply {
        files.take(50).forEach { file ->
            put(JSONObject()
                .put("title", file.title)
                .put("uri", file.uri)
                .put("lastOpenedAt", file.lastOpenedAt)
                .put("pinned", file.pinned)
            )
        }
    }

    private fun recentFromJson(array: JSONArray): List<RecentFile> = buildList {
        for (i in 0 until array.length()) {
            val item = array.getJSONObject(i)
            add(RecentFile(
                title = item.optString("title", "Recent file"),
                uri = item.optString("uri", ""),
                lastOpenedAt = item.optLong("lastOpenedAt", 0L),
                pinned = item.optBoolean("pinned", false)
            ))
        }
    }.filter { it.uri.isNotBlank() }

    private inline fun <reified T : Enum<T>> enumValue(name: String?, fallback: T): T =
        enumValues<T>().firstOrNull { it.name == name } ?: fallback
}
