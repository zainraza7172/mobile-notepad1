package com.jin.notepad

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isCtrlPressed
import androidx.compose.ui.input.key.isShiftPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.jin.notepad.model.EditorTab
import com.jin.notepad.model.ThemeMode
import com.jin.notepad.ui.EditorViewModel
import com.jin.notepad.ui.JinNotepadTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private val editorViewModel: EditorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        editorViewModel.handleExternalIntent(this, intent)
        setContent {
            val state = editorViewModel.uiState
            JinNotepadTheme(state.settings.themeMode) {
                JinNotepadApp(editorViewModel)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        editorViewModel.handleExternalIntent(this, intent)
    }
}

private enum class DesktopMenu { FILE, EDIT, VIEW }

@Composable
private fun JinNotepadApp(viewModel: EditorViewModel) {
    val state = viewModel.uiState
    val context = LocalContext.current
    val density = LocalDensity.current
    val imeVisible = WindowInsets.ime.getBottom(density) > 0
    var openMenu by remember { mutableStateOf<DesktopMenu?>(null) }
    var pendingClose by remember { mutableStateOf<EditorTab?>(null) }
    var closeAfterSaveTabId by remember { mutableStateOf<String?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }
    val focusRequester = remember { FocusRequester() }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { viewModel.openUri(context, it) }
    }
    val saveAsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        uri?.let { selectedUri ->
            val closeId = closeAfterSaveTabId
            viewModel.saveAs(context, selectedUri) {
                if (closeId != null) viewModel.closeTab(closeId)
                closeAfterSaveTabId = null
            }
        } ?: run { closeAfterSaveTabId = null }
    }

    fun save() {
        val tab = state.activeTab ?: return
        if (tab.uri == null) saveAsLauncher.launch(suggestedSaveName(tab.title))
        else viewModel.saveCurrent(context)
    }

    fun requestClose(tab: EditorTab) {
        if (tab.isDirty) pendingClose = tab else viewModel.closeTab(tab.id)
    }

    fun shareCurrent() {
        val tab = state.activeTab ?: return
        val intent = if (tab.uri != null) {
            Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_STREAM, Uri.parse(tab.uri))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } else {
            Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, tab.value.text)
            }
        }
        context.startActivity(Intent.createChooser(intent, "Share with"))
    }

    LaunchedEffect(state.message) {
        val message = state.message ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(message)
        viewModel.clearMessage()
    }

    LaunchedEffect(state.activeTabId) {
        focusRequester.requestFocus()
    }

    val shortcutModifier = Modifier.onPreviewKeyEvent { event ->
        if (event.type != KeyEventType.KeyDown || !event.isCtrlPressed) return@onPreviewKeyEvent false
        when (event.key) {
            Key.N -> { viewModel.newTab(); true }
            Key.O -> { openLauncher.launch(arrayOf("*/*")); true }
            Key.S -> {
                if (event.isShiftPressed) saveAsLauncher.launch(suggestedSaveName(state.activeTab?.title ?: "Untitled.txt"))
                else save()
                true
            }
            Key.F -> { viewModel.setFindVisible(true); true }
            Key.H -> { viewModel.setFindVisible(true, replace = true); true }
            Key.Z -> { viewModel.undo(); true }
            Key.Y -> { viewModel.redo(); true }
            Key.A -> { viewModel.selectAll(); true }
            Key.W -> { state.activeTab?.let(::requestClose); true }
            else -> false
        }
    }

    Scaffold(
        modifier = shortcutModifier
            .fillMaxSize()
            .imePadding(),
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            WindowsLikeTopBar(
                tabs = state.tabs,
                activeTabId = state.activeTabId,
                activeTitle = state.activeTab?.title ?: "Untitled",
                activeDirty = state.activeTab?.isDirty == true,
                openMenu = openMenu,
                canUndo = state.activeTab?.undoStack?.isNotEmpty() == true,
                canRedo = state.activeTab?.redoStack?.isNotEmpty() == true,
                wordWrap = state.settings.wordWrap,
                lineNumbers = state.settings.lineNumbers,
                onMenuChange = { openMenu = it },
                onSelect = viewModel::selectTab,
                onClose = { id -> state.tabs.firstOrNull { it.id == id }?.let(::requestClose) },
                onNew = viewModel::newTab,
                onOpen = { openLauncher.launch(arrayOf("*/*")) },
                onSave = ::save,
                onSaveAs = { saveAsLauncher.launch(suggestedSaveName(state.activeTab?.title ?: "Untitled.txt")) },
                onRecent = { viewModel.showRecent(true) },
                onShare = ::shareCurrent,
                onUndo = viewModel::undo,
                onRedo = viewModel::redo,
                onFind = { viewModel.setFindVisible(true) },
                onReplace = { viewModel.setFindVisible(true, replace = true) },
                onSelectAll = viewModel::selectAll,
                onWordWrap = viewModel::setWordWrap,
                onLineNumbers = viewModel::setLineNumbers,
                onZoomOut = { viewModel.setFontSize(state.settings.fontSizeSp - 1f) },
                onZoomIn = { viewModel.setFontSize(state.settings.fontSizeSp + 1f) },
                onZoomReset = { viewModel.setFontSize(17f) },
                onSettings = { viewModel.showSettings(true) }
            )
        },
        bottomBar = {
            if (!imeVisible) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                ) {
                    if (state.settings.showQuickToolbar) {
                        QuickToolbar(
                            canUndo = state.activeTab?.undoStack?.isNotEmpty() == true,
                            canRedo = state.activeTab?.redoStack?.isNotEmpty() == true,
                            onUndo = viewModel::undo,
                            onRedo = viewModel::redo,
                            onFind = { viewModel.setFindVisible(true) },
                            onSave = ::save,
                            onZoomOut = { viewModel.setFontSize(state.settings.fontSizeSp - 1f) },
                            onZoomIn = { viewModel.setFontSize(state.settings.fontSizeSp + 1f) }
                        )
                    }
                    StatusBar(state.activeTab, state.settings.fontSizeSp)
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (state.findVisible) {
                FindReplaceBar(
                    query = state.findQuery,
                    replace = state.replaceQuery,
                    replaceVisible = state.replaceVisible,
                    matchCase = state.matchCase,
                    onQuery = viewModel::setFindQuery,
                    onReplace = viewModel::setReplaceQuery,
                    onMatchCase = viewModel::setMatchCase,
                    onPrev = { viewModel.findNext(backwards = true) },
                    onNext = { viewModel.findNext() },
                    onReplaceOne = viewModel::replaceCurrent,
                    onReplaceAll = viewModel::replaceAll,
                    onClose = { viewModel.setFindVisible(false) }
                )
            }
            state.activeTab?.let { tab ->
                EditorPane(
                    modifier = Modifier.weight(1f),
                    tab = tab,
                    fontSize = state.settings.fontSizeSp,
                    wordWrap = state.settings.wordWrap,
                    lineNumbers = state.settings.lineNumbers,
                    focusRequester = focusRequester,
                    imeVisible = imeVisible,
                    onValueChange = viewModel::updateText
                )
            }
        }
    }

    pendingClose?.let { tab ->
        AlertDialog(
            onDismissRequest = { pendingClose = null },
            title = { Text("Unsaved changes") },
            text = { Text("Save changes to ${tab.title} before closing?") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.selectTab(tab.id)
                    pendingClose = null
                    if (tab.uri == null) {
                        closeAfterSaveTabId = tab.id
                        saveAsLauncher.launch(suggestedSaveName(tab.title))
                    } else {
                        viewModel.saveCurrent(context) { viewModel.closeTab(tab.id) }
                    }
                }) { Text("Save") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { pendingClose = null }) { Text("Cancel") }
                    TextButton(onClick = { pendingClose = null; viewModel.closeTab(tab.id) }) { Text("Don't Save") }
                }
            }
        )
    }

    if (state.settingsVisible) SettingsDialog(viewModel)
    if (state.recentVisible) RecentFilesDialog(viewModel)
}

@Composable
private fun WindowsLikeTopBar(
    tabs: List<EditorTab>,
    activeTabId: String,
    activeTitle: String,
    activeDirty: Boolean,
    openMenu: DesktopMenu?,
    canUndo: Boolean,
    canRedo: Boolean,
    wordWrap: Boolean,
    lineNumbers: Boolean,
    onMenuChange: (DesktopMenu?) -> Unit,
    onSelect: (String) -> Unit,
    onClose: (String) -> Unit,
    onNew: () -> Unit,
    onOpen: () -> Unit,
    onSave: () -> Unit,
    onSaveAs: () -> Unit,
    onRecent: () -> Unit,
    onShare: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onFind: () -> Unit,
    onReplace: () -> Unit,
    onSelectAll: () -> Unit,
    onWordWrap: (Boolean) -> Unit,
    onLineNumbers: (Boolean) -> Unit,
    onZoomOut: () -> Unit,
    onZoomIn: () -> Unit,
    onZoomReset: () -> Unit,
    onSettings: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
    ) {
        Surface(tonalElevation = 3.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(42.dp)
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "J",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(end = 8.dp)
                )
                Text(
                    text = "Jin Notepad",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    text = if (activeDirty) "$activeTitle •" else activeTitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = onFind, contentPadding = PaddingValues(horizontal = 10.dp)) {
                    Text("Find")
                }
            }
        }

        TabsBar(
            tabs = tabs,
            activeTabId = activeTabId,
            onSelect = onSelect,
            onClose = onClose,
            onNew = onNew
        )

        Surface(tonalElevation = 2.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(38.dp)
                    .padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                DesktopMenuButton(
                    label = "File",
                    expanded = openMenu == DesktopMenu.FILE,
                    onExpandedChange = { onMenuChange(if (it) DesktopMenu.FILE else null) }
                ) {
                    MenuItem("New", "Ctrl+N") { onMenuChange(null); onNew() }
                    MenuItem("Open…", "Ctrl+O") { onMenuChange(null); onOpen() }
                    HorizontalDivider()
                    MenuItem("Save", "Ctrl+S") { onMenuChange(null); onSave() }
                    MenuItem("Save As…", "Ctrl+Shift+S") { onMenuChange(null); onSaveAs() }
                    HorizontalDivider()
                    MenuItem("Recent Files") { onMenuChange(null); onRecent() }
                    MenuItem("Share") { onMenuChange(null); onShare() }
                }

                DesktopMenuButton(
                    label = "Edit",
                    expanded = openMenu == DesktopMenu.EDIT,
                    onExpandedChange = { onMenuChange(if (it) DesktopMenu.EDIT else null) }
                ) {
                    MenuItem("Undo", "Ctrl+Z", enabled = canUndo) { onMenuChange(null); onUndo() }
                    MenuItem("Redo", "Ctrl+Y", enabled = canRedo) { onMenuChange(null); onRedo() }
                    HorizontalDivider()
                    MenuItem("Find", "Ctrl+F") { onMenuChange(null); onFind() }
                    MenuItem("Replace", "Ctrl+H") { onMenuChange(null); onReplace() }
                    MenuItem("Select All", "Ctrl+A") { onMenuChange(null); onSelectAll() }
                }

                DesktopMenuButton(
                    label = "View",
                    expanded = openMenu == DesktopMenu.VIEW,
                    onExpandedChange = { onMenuChange(if (it) DesktopMenu.VIEW else null) }
                ) {
                    MenuItem(if (wordWrap) "✓  Word Wrap" else "Word Wrap") {
                        onMenuChange(null); onWordWrap(!wordWrap)
                    }
                    MenuItem(if (lineNumbers) "✓  Line Numbers" else "Line Numbers") {
                        onMenuChange(null); onLineNumbers(!lineNumbers)
                    }
                    HorizontalDivider()
                    MenuItem("Zoom In", "Ctrl++") { onMenuChange(null); onZoomIn() }
                    MenuItem("Zoom Out", "Ctrl+-") { onMenuChange(null); onZoomOut() }
                    MenuItem("Restore Default Zoom") { onMenuChange(null); onZoomReset() }
                    HorizontalDivider()
                    MenuItem("Settings") { onMenuChange(null); onSettings() }
                }

                Spacer(Modifier.weight(1f))
                Text(
                    text = "UTF-8",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(end = 8.dp)
                )
            }
        }
    }
}

@Composable
private fun DesktopMenuButton(
    label: String,
    expanded: Boolean,
    onExpandedChange: (Boolean) -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Box {
        TextButton(
            onClick = { onExpandedChange(!expanded) },
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
            modifier = Modifier.height(34.dp)
        ) {
            Text(label)
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { onExpandedChange(false) },
            content = content
        )
    }
}

@Composable
private fun ColumnScope.MenuItem(
    label: String,
    shortcut: String? = null,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    DropdownMenuItem(
        text = {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(label, modifier = Modifier.weight(1f))
                if (!shortcut.isNullOrBlank()) {
                    Text(
                        shortcut,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        enabled = enabled,
        onClick = onClick
    )
}

@Composable
private fun TabsBar(
    tabs: List<EditorTab>,
    activeTabId: String,
    onSelect: (String) -> Unit,
    onClose: (String) -> Unit,
    onNew: () -> Unit
) {
    Surface(tonalElevation = 1.dp) {
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items(tabs, key = { it.id }) { tab ->
                Surface(
                    shape = RoundedCornerShape(topStart = 7.dp, topEnd = 7.dp, bottomStart = 3.dp, bottomEnd = 3.dp),
                    color = if (tab.id == activeTabId) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface,
                    border = if (tab.id == activeTabId) BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant) else null,
                    modifier = Modifier.clickable { onSelect(tab.id) }
                ) {
                    Row(
                        modifier = Modifier
                            .height(42.dp)
                            .padding(start = 12.dp, end = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            if (tab.isDirty) "${tab.title} •" else tab.title,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.widthIn(max = 170.dp)
                        )
                        TextButton(
                            onClick = { onClose(tab.id) },
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.size(34.dp)
                        ) { Text("×", fontSize = 18.sp) }
                    }
                }
            }
            item {
                TextButton(
                    onClick = onNew,
                    modifier = Modifier.size(40.dp),
                    contentPadding = PaddingValues(0.dp)
                ) { Text("+", fontSize = 20.sp) }
            }
        }
    }
}

@Composable
private fun EditorPane(
    modifier: Modifier = Modifier,
    tab: EditorTab,
    fontSize: Float,
    wordWrap: Boolean,
    lineNumbers: Boolean,
    focusRequester: FocusRequester,
    imeVisible: Boolean,
    onValueChange: (TextFieldValue) -> Unit
) {
    val verticalScroll = rememberScrollState()
    val horizontalScroll = rememberScrollState()
    val bringIntoViewRequester = remember { BringIntoViewRequester() }
    val density = LocalDensity.current
    var textLayoutResult by remember { mutableStateOf<TextLayoutResult?>(null) }
    val lineCount = remember(tab.value.text) { tab.value.text.count { it == '\n' } + 1 }

    LaunchedEffect(tab.value.selection.end, tab.value.text.length, imeVisible) {
        if (!imeVisible) return@LaunchedEffect
        delay(70)
        val layout = textLayoutResult ?: return@LaunchedEffect
        val offset = tab.value.selection.end.coerceIn(0, tab.value.text.length)
        val cursorRect = layout.getCursorRect(offset)
        val extraBottom = with(density) { 72.dp.toPx() }
        val extraTop = with(density) { 28.dp.toPx() }
        bringIntoViewRequester.bringIntoView(
            Rect(
                left = cursorRect.left,
                top = (cursorRect.top - extraTop).coerceAtLeast(0f),
                right = cursorRect.right + 12f,
                bottom = cursorRect.bottom + extraBottom
            )
        )
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val viewportMinHeight = (maxHeight - 12.dp).coerceAtLeast(180.dp)
        Row(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(verticalScroll)
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            if (lineNumbers) {
                Text(
                    text = (1..lineCount).joinToString("\n"),
                    fontFamily = FontFamily.Monospace,
                    fontSize = fontSize.sp,
                    lineHeight = (fontSize * 1.48f).sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f),
                    modifier = Modifier.padding(end = 12.dp)
                )
                VerticalDivider(
                    modifier = Modifier
                        .heightIn(min = viewportMinHeight)
                        .padding(end = 8.dp),
                    color = MaterialTheme.colorScheme.outlineVariant
                )
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .then(if (wordWrap) Modifier else Modifier.horizontalScroll(horizontalScroll))
            ) {
                androidx.compose.foundation.text.BasicTextField(
                    value = tab.value,
                    onValueChange = onValueChange,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(
                        color = MaterialTheme.colorScheme.onSurface,
                        fontFamily = FontFamily.Monospace,
                        fontSize = fontSize.sp,
                        lineHeight = (fontSize * 1.48f).sp
                    ),
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                    onTextLayout = { textLayoutResult = it },
                    modifier = Modifier
                        .focusRequester(focusRequester)
                        .bringIntoViewRequester(bringIntoViewRequester)
                        .heightIn(min = viewportMinHeight)
                        .then(if (wordWrap) Modifier.fillMaxWidth() else Modifier.widthIn(min = 1800.dp))
                )
            }
        }
    }
}

@Composable
private fun QuickToolbar(
    canUndo: Boolean,
    canRedo: Boolean,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onFind: () -> Unit,
    onSave: () -> Unit,
    onZoomOut: () -> Unit,
    onZoomIn: () -> Unit
) {
    Surface(tonalElevation = 3.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 6.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(enabled = canUndo, onClick = onUndo) { Text("Undo") }
            TextButton(enabled = canRedo, onClick = onRedo) { Text("Redo") }
            TextButton(onClick = onFind) { Text("Find") }
            TextButton(onClick = onSave) { Text("Save") }
            TextButton(onClick = onZoomOut) { Text("A−") }
            TextButton(onClick = onZoomIn) { Text("A+") }
        }
    }
}

@Composable
private fun StatusBar(tab: EditorTab?, fontSize: Float) {
    val text = tab?.value?.text.orEmpty()
    val cursor = tab?.value?.selection?.start?.coerceIn(0, text.length) ?: 0
    val before = text.take(cursor)
    val line = before.count { it == '\n' } + 1
    val column = cursor - (before.lastIndexOf('\n').takeIf { it >= 0 } ?: -1)
    val words = remember(text) { Regex("\\S+").findAll(text).count() }
    val zoom = ((fontSize / 17f) * 100).toInt()

    Surface(tonalElevation = 2.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Ln $line, Col $column", style = MaterialTheme.typography.labelSmall)
            StatusSeparator()
            Text("$words words", style = MaterialTheme.typography.labelSmall)
            StatusSeparator()
            Text("${text.length} chars", style = MaterialTheme.typography.labelSmall)
            StatusSeparator()
            Text("UTF-8", style = MaterialTheme.typography.labelSmall)
            StatusSeparator()
            Text("LF", style = MaterialTheme.typography.labelSmall)
            StatusSeparator()
            Text("$zoom%", style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun StatusSeparator() {
    Text(
        "  |  ",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.outline
    )
}

@Composable
private fun FindReplaceBar(
    query: String,
    replace: String,
    replaceVisible: Boolean,
    matchCase: Boolean,
    onQuery: (String) -> Unit,
    onReplace: (String) -> Unit,
    onMatchCase: (Boolean) -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onReplaceOne: () -> Unit,
    onReplaceAll: () -> Unit,
    onClose: () -> Unit
) {
    Surface(tonalElevation = 5.dp, shadowElevation = 2.dp) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = query,
                    onValueChange = onQuery,
                    placeholder = { Text("Find") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(4.dp))
                TextButton(onClick = onPrev) { Text("↑") }
                TextButton(onClick = onNext) { Text("↓") }
                TextButton(onClick = onClose) { Text("×") }
            }
            if (replaceVisible) {
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = replace,
                        onValueChange = onReplace,
                        placeholder = { Text("Replace with") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = onReplaceOne) { Text("Replace") }
                    TextButton(onClick = onReplaceAll) { Text("All") }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = matchCase, onCheckedChange = onMatchCase)
                Text("Match case", style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@Composable
private fun SettingsDialog(viewModel: EditorViewModel) {
    val settings = viewModel.uiState.settings
    AlertDialog(
        onDismissRequest = { viewModel.showSettings(false) },
        title = { Text("Jin Notepad settings") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Appearance", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                ThemeMode.entries.forEach { mode ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.setTheme(mode) }
                            .padding(vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = settings.themeMode == mode, onClick = { viewModel.setTheme(mode) })
                        Text(mode.name.lowercase().replaceFirstChar { it.uppercase() })
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 6.dp))
                Text("Editor", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                SettingSwitch("Word Wrap", settings.wordWrap, viewModel::setWordWrap)
                SettingSwitch("Line Numbers", settings.lineNumbers, viewModel::setLineNumbers)
                SettingSwitch("Bottom Quick Toolbar", settings.showQuickToolbar, viewModel::setShowQuickToolbar)
                SettingSwitch("Auto Save existing files", settings.autoSave, viewModel::setAutoSave)
                SettingSwitch("Restore Session", settings.sessionRestore, viewModel::setSessionRestore)
                Spacer(Modifier.height(8.dp))
                Text("Font size: ${settings.fontSizeSp.toInt()} sp")
                Slider(
                    value = settings.fontSizeSp,
                    onValueChange = viewModel::setFontSize,
                    valueRange = 10f..32f,
                    steps = 21
                )
                Text(
                    "Auto Save writes only files that already have a saved location. New unsaved tabs are still protected by session recovery.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = { TextButton(onClick = { viewModel.showSettings(false) }) { Text("Done") } }
    )
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun RecentFilesDialog(viewModel: EditorViewModel) {
    val state = viewModel.uiState
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = { viewModel.showRecent(false) },
        title = { Text("Recent Files") },
        text = {
            if (state.recentFiles.isEmpty()) {
                Text("No recent files yet.")
            } else {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    state.recentFiles.forEach { file ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.showRecent(false)
                                    viewModel.openRecent(context, file.uri)
                                }
                                .padding(vertical = 10.dp)
                        ) {
                            Text(file.title, style = MaterialTheme.typography.bodyLarge)
                            Text(file.uri, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                        }
                        HorizontalDivider()
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { viewModel.showRecent(false) }) { Text("Close") } }
    )
}

private fun suggestedSaveName(title: String): String {
    val trimmed = title.trim().ifEmpty { "Untitled" }
    return if ('.' in trimmed) trimmed else "$trimmed.txt"
}
