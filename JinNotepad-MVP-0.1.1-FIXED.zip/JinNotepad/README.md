# Jin Notepad

A clean, offline-first Android text editor inspired by the simplicity of desktop Notepad, without copying Microsoft branding.

## Package

`com.jin.notepad`

## Current milestone — MVP 0.1.0

Implemented:

- Offline editor; no login, ads, analytics, or Internet permission
- Multiple tabs
- New / Open / Save / Save As
- Android Storage Access Framework file picker
- Open With support for text and common text-like MIME types
- UTF-8 saving; UTF-8 BOM / UTF-16 BOM reading
- Undo / Redo
- Find / Replace / Replace All / Match Case
- Word Wrap setting
- Optional line numbers
- Font size controls
- Line / column, word count, character count, encoding status
- Recent files
- Session restore, including unsaved tab text
- Light / Dark / System theme
- Share as file or text
- External keyboard shortcuts: Ctrl+N/O/S/Shift+S/F/H/Z/Y/W
- Mobile quick toolbar
- GitHub Actions workflow that builds a debug APK

## Build

Recommended: Android Studio Quail 4 (2026.1.4) or newer, JDK 17, Android SDK 36.

Open this folder in Android Studio and sync the project. You can also run:

```bash
./gradlew :app:assembleDebug
```

The included `gradlew` / `gradlew.bat` are lightweight bootstrap scripts that fetch Gradle 9.6.0 on first use. The GitHub workflow uses Gradle directly and does not depend on a wrapper JAR.

Debug APK output:

`app/build/outputs/apk/debug/app-debug.apk`

## Next milestone

Planned after MVP verification:

- More robust large-file mode
- Encoding picker and line-ending conversion (LF/CRLF)
- Auto-save modes
- Markdown toolbar + preview
- Better tablet/landscape desktop-style layout
- Customizable quick toolbar
- Recently closed tabs
- More precise no-wrap editor implementation


## v0.1.1 build fix
- Added missing `androidx.activity.compose.setContent` import.
- Pinned Compose to 1.11.4 / Material3 1.4.0 to stay compatible with compileSdk 36.
- Pinned Core, Activity, and Lifecycle to API 36-compatible stable versions.
- Updated GitHub Actions Android SDK setup.
