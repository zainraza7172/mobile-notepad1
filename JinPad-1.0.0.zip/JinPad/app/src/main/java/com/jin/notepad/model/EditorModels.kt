package com.jin.notepad.model

import androidx.compose.ui.text.input.TextFieldValue
import java.util.UUID

enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class TextEncoding(val label: String) {
    UTF8("UTF-8"),
    UTF8_BOM("UTF-8 BOM"),
    UTF16_LE("UTF-16 LE"),
    UTF16_BE("UTF-16 BE")
}
enum class LineEnding(val label: String) {
    LF("LF"),
    CRLF("CRLF"),
    CR("CR")
}

data class EditorSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val wordWrap: Boolean = true,
    val lineNumbers: Boolean = false,
    val fontSizeSp: Float = 17f,
    val sessionRestore: Boolean = true,
    val autoSave: Boolean = false,
    val autoSaveDelaySeconds: Int = 2,
    val showQuickToolbar: Boolean = true,
    val showStatusBar: Boolean = true,
    val syntaxHighlighting: Boolean = true,
    val tabWidth: Int = 4,
    val markdownPreview: Boolean = true,
    val defaultEncoding: TextEncoding = TextEncoding.UTF8,
    val defaultLineEnding: LineEnding = LineEnding.LF
)

data class RecentFile(
    val title: String,
    val uri: String,
    val lastOpenedAt: Long,
    val pinned: Boolean = false
)

data class EditorTab(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val uri: String? = null,
    val value: TextFieldValue = TextFieldValue(""),
    val savedText: String = "",
    val encoding: TextEncoding = TextEncoding.UTF8,
    val lineEnding: LineEnding = LineEnding.LF,
    val undoStack: List<TextFieldValue> = emptyList(),
    val redoStack: List<TextFieldValue> = emptyList()
) {
    val isDirty: Boolean get() = value.text != savedText
    val extension: String get() = title.substringAfterLast('.', "").lowercase()
    val isMarkdown: Boolean get() = extension in setOf("md", "markdown")
    val isLargeFile: Boolean get() = value.text.length >= 1_000_000
}

data class EditorUiState(
    val tabs: List<EditorTab> = listOf(EditorTab(title = "Untitled 1.txt")),
    val activeTabId: String = tabs.first().id,
    val settings: EditorSettings = EditorSettings(),
    val recentFiles: List<RecentFile> = emptyList(),
    val findVisible: Boolean = false,
    val replaceVisible: Boolean = false,
    val findQuery: String = "",
    val replaceQuery: String = "",
    val matchCase: Boolean = false,
    val wholeWord: Boolean = false,
    val regexSearch: Boolean = false,
    val settingsVisible: Boolean = false,
    val recentVisible: Boolean = false,
    val goToLineVisible: Boolean = false,
    val fileInfoVisible: Boolean = false,
    val newFileVisible: Boolean = false,
    val markdownPreviewVisible: Boolean = false,
    val message: String? = null
) {
    val activeTab: EditorTab? get() = tabs.firstOrNull { it.id == activeTabId }
}
