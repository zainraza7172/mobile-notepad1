package com.jin.notepad.model

import androidx.compose.ui.text.input.TextFieldValue
import java.util.UUID


enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class EditorSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val wordWrap: Boolean = true,
    val lineNumbers: Boolean = false,
    val fontSizeSp: Float = 17f,
    val sessionRestore: Boolean = true
)

data class RecentFile(
    val title: String,
    val uri: String,
    val lastOpenedAt: Long
)

data class EditorTab(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val uri: String? = null,
    val value: TextFieldValue = TextFieldValue(""),
    val savedText: String = "",
    val undoStack: List<TextFieldValue> = emptyList(),
    val redoStack: List<TextFieldValue> = emptyList()
) {
    val isDirty: Boolean get() = value.text != savedText
}

data class EditorUiState(
    val tabs: List<EditorTab> = listOf(EditorTab(title = "Untitled 1")),
    val activeTabId: String = tabs.first().id,
    val settings: EditorSettings = EditorSettings(),
    val recentFiles: List<RecentFile> = emptyList(),
    val findVisible: Boolean = false,
    val replaceVisible: Boolean = false,
    val findQuery: String = "",
    val replaceQuery: String = "",
    val matchCase: Boolean = false,
    val settingsVisible: Boolean = false,
    val recentVisible: Boolean = false,
    val message: String? = null
) {
    val activeTab: EditorTab? get() = tabs.firstOrNull { it.id == activeTabId }
}
