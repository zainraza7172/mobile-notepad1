package com.jin.notepad.data

import android.content.Context
import com.jin.notepad.model.EditorSettings
import com.jin.notepad.model.RecentFile
import com.jin.notepad.model.ThemeMode
import org.json.JSONArray
import org.json.JSONObject

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("jin_notepad_settings", Context.MODE_PRIVATE)

    fun loadSettings(): EditorSettings {
        val theme = runCatching {
            ThemeMode.valueOf(prefs.getString("theme", ThemeMode.SYSTEM.name) ?: ThemeMode.SYSTEM.name)
        }.getOrDefault(ThemeMode.SYSTEM)
        return EditorSettings(
            themeMode = theme,
            wordWrap = prefs.getBoolean("word_wrap", true),
            lineNumbers = prefs.getBoolean("line_numbers", false),
            fontSizeSp = prefs.getFloat("font_size", 17f),
            sessionRestore = prefs.getBoolean("session_restore", true)
        )
    }

    fun saveSettings(settings: EditorSettings) {
        prefs.edit()
            .putString("theme", settings.themeMode.name)
            .putBoolean("word_wrap", settings.wordWrap)
            .putBoolean("line_numbers", settings.lineNumbers)
            .putFloat("font_size", settings.fontSizeSp)
            .putBoolean("session_restore", settings.sessionRestore)
            .apply()
    }

    fun loadRecentFiles(): List<RecentFile> {
        val raw = prefs.getString("recent_files", null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)
                    add(
                        RecentFile(
                            title = item.getString("title"),
                            uri = item.getString("uri"),
                            lastOpenedAt = item.optLong("lastOpenedAt", 0L)
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    fun saveRecentFiles(files: List<RecentFile>) {
        val array = JSONArray()
        files.take(30).forEach { file ->
            array.put(
                JSONObject()
                    .put("title", file.title)
                    .put("uri", file.uri)
                    .put("lastOpenedAt", file.lastOpenedAt)
            )
        }
        prefs.edit().putString("recent_files", array.toString()).apply()
    }
}
