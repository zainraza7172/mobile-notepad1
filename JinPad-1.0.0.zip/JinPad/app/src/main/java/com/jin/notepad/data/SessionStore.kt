package com.jin.notepad.data

import android.content.Context
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import com.jin.notepad.model.EditorTab
import com.jin.notepad.model.LineEnding
import com.jin.notepad.model.TextEncoding
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class SessionStore(context: Context) {
    private val file = File(context.filesDir, "editor_session.json")

    fun load(): Pair<List<EditorTab>, String?>? {
        if (!file.exists()) return null
        return runCatching {
            val root = JSONObject(file.readText())
            val activeId = root.optString("activeTabId").takeIf { it.isNotBlank() }
            val array = root.getJSONArray("tabs")
            val tabs = buildList {
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)
                    val text = item.optString("text", "")
                    val selectionStart = item.optInt("selectionStart", 0).coerceIn(0, text.length)
                    val selectionEnd = item.optInt("selectionEnd", selectionStart).coerceIn(0, text.length)
                    val encoding = TextEncoding.entries.firstOrNull { it.name == item.optString("encoding") } ?: TextEncoding.UTF8
                    val lineEnding = LineEnding.entries.firstOrNull { it.name == item.optString("lineEnding") } ?: LineEnding.LF
                    add(
                        EditorTab(
                            id = item.getString("id"),
                            title = item.optString("title", "Untitled.txt"),
                            uri = item.optString("uri").takeIf { it.isNotBlank() },
                            value = TextFieldValue(text, selection = TextRange(selectionStart, selectionEnd)),
                            savedText = item.optString("savedText", ""),
                            encoding = encoding,
                            lineEnding = lineEnding
                        )
                    )
                }
            }
            if (tabs.isEmpty()) null else tabs to activeId
        }.getOrNull()
    }

    fun save(tabs: List<EditorTab>, activeTabId: String) {
        runCatching {
            val array = JSONArray()
            tabs.forEach { tab ->
                array.put(
                    JSONObject()
                        .put("id", tab.id)
                        .put("title", tab.title)
                        .put("uri", tab.uri ?: "")
                        .put("text", tab.value.text)
                        .put("savedText", tab.savedText)
                        .put("selectionStart", tab.value.selection.start)
                        .put("selectionEnd", tab.value.selection.end)
                        .put("encoding", tab.encoding.name)
                        .put("lineEnding", tab.lineEnding.name)
                )
            }
            val root = JSONObject()
                .put("activeTabId", activeTabId)
                .put("tabs", array)
            file.writeText(root.toString())
        }
    }

    fun clear() {
        runCatching { file.delete() }
    }
}
