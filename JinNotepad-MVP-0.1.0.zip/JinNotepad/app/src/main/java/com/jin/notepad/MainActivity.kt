package com.jin.notepad

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isCtrlPressed
import androidx.compose.ui.input.key.isShiftPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jin.notepad.model.EditorTab
import com.jin.notepad.model.ThemeMode
import com.jin.notepad.ui.EditorViewModel
import com.jin.notepad.ui.JinNotepadTheme

class MainActivity : ComponentActivity() {
    private val editorViewModel: EditorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        editorViewModel.handleExternalIntent(this, intent)
        setContent {
            val state = editorViewModel.uiState
            JinNotepadTheme(state.settings.themeMode) {
                JinNotepadApp(editorViewModel)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        editorViewModel.handleExternalIntent(this, intent)
    }
}

@Composable
private fun JinNotepadApp(viewModel: EditorViewModel) {
    val state = viewModel.uiState
    val context = LocalContext.current
    var menuExpanded by remember { mutableStateOf(false) }
    var pendingClose by remember { mutableStateOf<EditorTab?>(null) }
    var closeAfterSaveTabId by remember { mutableStateOf<String?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }
    val focusRequester = remember { FocusRequester() }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { viewModel.openUri(context, it) }
    }
    val saveAsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        uri?.let { selectedUri ->
            val closeId = closeAfterSaveTabId
            viewModel.saveAs(context, selectedUri) {
                if (closeId != null) viewModel.closeTab(closeId)
                closeAfterSaveTabId = null
            }
        } ?: run { closeAfterSaveTabId = null }
    }

    fun save() {
        val tab = state.activeTab ?: return
        if (tab.uri == null) saveAsLauncher.launch(suggestedSaveName(tab.title))
        else viewModel.saveCurrent(context)
    }

    fun requestClose(tab: EditorTab) {
        if (tab.isDirty) pendingClose = tab else viewModel.closeTab(tab.id)
    }

    fun shareCurrent() {
        val tab = state.activeTab ?: return
        val intent = if (tab.uri != null) {
            Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_STREAM, Uri.parse(tab.uri))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } else {
            Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, tab.value.text)
            }
        }
        context.startActivity(Intent.createChooser(intent, "Share with"))
    }

    LaunchedEffect(state.message) {
        val message = state.message ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(message)
        viewModel.clearMessage()
    }

    LaunchedEffect(state.activeTabId) {
        focusRequester.requestFocus()
    }

    val shortcutModifier = Modifier.onPreviewKeyEvent { event ->
        if (event.type != KeyEventType.KeyDown || !event.isCtrlPressed) return@onPreviewKeyEvent false
        when (event.key) {
            Key.N -> { viewModel.newTab(); true }
            Key.O -> { openLauncher.launch(arrayOf("*/*")); true }
            Key.S -> {
                if (event.isShiftPressed) saveAsLauncher.launch(suggestedSaveName(state.activeTab?.title ?: "Untitled.txt"))
                else save()
                true
            }
            Key.F -> { viewModel.setFindVisible(true); true }
            Key.H -> { viewModel.setFindVisible(true, replace = true); true }
            Key.Z -> { viewModel.undo(); true }
            Key.Y -> { viewModel.redo(); true }
            Key.W -> { state.activeTab?.let(::requestClose); true }
            else -> false
        }
    }

    Scaffold(
        modifier = shortcutModifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Column {
                Surface(tonalElevation = 2.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Jin Notepad",
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = { viewModel.setFindVisible(true) }) { Text("Find") }
                        TextButton(onClick = { menuExpanded = true }) { Text("⋮", fontSize = 22.sp) }
                        DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                            DropdownMenuItem(text = { Text("New") }, onClick = { menuExpanded = false; viewModel.newTab() })
                            DropdownMenuItem(text = { Text("Open…") }, onClick = { menuExpanded = false; openLauncher.launch(arrayOf("*/*")) })
                            DropdownMenuItem(text = { Text("Save") }, onClick = { menuExpanded = false; save() })
                            DropdownMenuItem(text = { Text("Save As…") }, onClick = {
                                menuExpanded = false
                                saveAsLauncher.launch(suggestedSaveName(state.activeTab?.title ?: "Untitled.txt"))
                            })
                            HorizontalDivider()
                            DropdownMenuItem(text = { Text("Find / Replace") }, onClick = { menuExpanded = false; viewModel.setFindVisible(true, replace = true) })
                            DropdownMenuItem(text = { Text("Recent Files") }, onClick = { menuExpanded = false; viewModel.showRecent(true) })
                            DropdownMenuItem(text = { Text("Share") }, onClick = { menuExpanded = false; shareCurrent() })
                            DropdownMenuItem(text = { Text("Settings") }, onClick = { menuExpanded = false; viewModel.showSettings(true) })
                        }
                    }
                }
                TabsBar(
                    tabs = state.tabs,
                    activeTabId = state.activeTabId,
                    onSelect = viewModel::selectTab,
                    onClose = { id -> state.tabs.firstOrNull { it.id == id }?.let(::requestClose) },
                    onNew = viewModel::newTab
                )
            }
        },
        bottomBar = {
            Column {
                QuickToolbar(
                    canUndo = state.activeTab?.undoStack?.isNotEmpty() == true,
                    canRedo = state.activeTab?.redoStack?.isNotEmpty() == true,
                    onUndo = viewModel::undo,
                    onRedo = viewModel::redo,
                    onFind = { viewModel.setFindVisible(true) },
                    onSave = ::save,
                    onZoomOut = { viewModel.setFontSize(state.settings.fontSizeSp - 1f) },
                    onZoomIn = { viewModel.setFontSize(state.settings.fontSizeSp + 1f) }
                )
                StatusBar(state.activeTab, state.settings.fontSizeSp)
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (state.findVisible) {
                FindReplaceBar(
                    query = state.findQuery,
                    replace = state.replaceQuery,
                    replaceVisible = state.replaceVisible,
                    matchCase = state.matchCase,
                    onQuery = viewModel::setFindQuery,
                    onReplace = viewModel::setReplaceQuery,
                    onMatchCase = viewModel::setMatchCase,
                    onPrev = { viewModel.findNext(backwards = true) },
                    onNext = { viewModel.findNext() },
                    onReplaceOne = viewModel::replaceCurrent,
                    onReplaceAll = viewModel::replaceAll,
                    onClose = { viewModel.setFindVisible(false) }
                )
            }
            state.activeTab?.let { tab ->
                EditorPane(
                    modifier = Modifier.weight(1f),
                    tab = tab,
                    fontSize = state.settings.fontSizeSp,
                    wordWrap = state.settings.wordWrap,
                    lineNumbers = state.settings.lineNumbers,
                    focusRequester = focusRequester,
                    onValueChange = viewModel::updateText
                )
            }
        }
    }

    pendingClose?.let { tab ->
        AlertDialog(
            onDismissRequest = { pendingClose = null },
            title = { Text("Unsaved changes") },
            text = { Text("Save changes to ${tab.title} before closing?") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.selectTab(tab.id)
                    pendingClose = null
                    if (tab.uri == null) {
                        closeAfterSaveTabId = tab.id
                        saveAsLauncher.launch(suggestedSaveName(tab.title))
                    } else {
                        viewModel.saveCurrent(context) { viewModel.closeTab(tab.id) }
                    }
                }) { Text("Save") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { pendingClose = null }) { Text("Cancel") }
                    TextButton(onClick = { pendingClose = null; viewModel.closeTab(tab.id) }) { Text("Don't Save") }
                }
            }
        )
    }

    if (state.settingsVisible) {
        SettingsDialog(viewModel)
    }

    if (state.recentVisible) {
        RecentFilesDialog(viewModel)
    }
}

@Composable
private fun TabsBar(
    tabs: List<EditorTab>,
    activeTabId: String,
    onSelect: (String) -> Unit,
    onClose: (String) -> Unit,
    onNew: () -> Unit
) {
    Surface(tonalElevation = 1.dp) {
        LazyRow(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items(tabs, key = { it.id }) { tab ->
                Surface(
                    shape = MaterialTheme.shapes.small,
                    tonalElevation = if (tab.id == activeTabId) 4.dp else 0.dp,
                    border = if (tab.id == activeTabId) BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant) else null,
                    modifier = Modifier.clickable { onSelect(tab.id) }
                ) {
                    Row(
                        modifier = Modifier.padding(start = 10.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (tab.isDirty) "${tab.title} •" else tab.title, maxLines = 1)
                        TextButton(
                            onClick = { onClose(tab.id) },
                            contentPadding = PaddingValues(4.dp),
                            modifier = Modifier.size(32.dp)
                        ) { Text("×", fontSize = 18.sp) }
                    }
                }
            }
            item {
                TextButton(onClick = onNew) { Text("+") }
            }
        }
    }
}

@Composable
private fun EditorPane(
    modifier: Modifier = Modifier,
    tab: EditorTab,
    fontSize: Float,
    wordWrap: Boolean,
    lineNumbers: Boolean,
    focusRequester: FocusRequester,
    onValueChange: (TextFieldValue) -> Unit
) {
    val verticalScroll = rememberScrollState()
    val horizontalScroll = rememberScrollState()
    val lineCount = remember(tab.value.text) { tab.value.text.count { it == '\n' } + 1 }

    Row(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(verticalScroll)
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        if (lineNumbers) {
            Text(
                text = (1..lineCount).joinToString("\n"),
                fontFamily = FontFamily.Monospace,
                fontSize = fontSize.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(end = 10.dp)
            )
        }
        Box(
            modifier = Modifier
                .weight(1f)
                .then(if (wordWrap) Modifier else Modifier.horizontalScroll(horizontalScroll))
        ) {
            androidx.compose.foundation.text.BasicTextField(
                value = tab.value,
                onValueChange = onValueChange,
                textStyle = MaterialTheme.typography.bodyLarge.copy(
                    color = MaterialTheme.colorScheme.onSurface,
                    fontFamily = FontFamily.Monospace,
                    fontSize = fontSize.sp,
                    lineHeight = (fontSize * 1.45f).sp
                ),
                cursorBrush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary),
                modifier = Modifier
                    .focusRequester(focusRequester)
                    .heightIn(min = 520.dp)
                    .then(if (wordWrap) Modifier.fillMaxWidth() else Modifier.widthIn(min = 1800.dp))
            )
        }
    }
}

@Composable
private fun QuickToolbar(
    canUndo: Boolean,
    canRedo: Boolean,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onFind: () -> Unit,
    onSave: () -> Unit,
    onZoomOut: () -> Unit,
    onZoomIn: () -> Unit
) {
    Surface(tonalElevation = 3.dp) {
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(enabled = canUndo, onClick = onUndo) { Text("Undo") }
            TextButton(enabled = canRedo, onClick = onRedo) { Text("Redo") }
            TextButton(onClick = onFind) { Text("Find") }
            TextButton(onClick = onSave) { Text("Save") }
            TextButton(onClick = onZoomOut) { Text("A−") }
            TextButton(onClick = onZoomIn) { Text("A+") }
        }
    }
}

@Composable
private fun StatusBar(tab: EditorTab?, fontSize: Float) {
    val text = tab?.value?.text.orEmpty()
    val cursor = tab?.value?.selection?.start?.coerceIn(0, text.length) ?: 0
    val before = text.take(cursor)
    val line = before.count { it == '\n' } + 1
    val column = cursor - (before.lastIndexOf('\n').takeIf { it >= 0 } ?: -1)
    val words = remember(text) { Regex("\\S+").findAll(text).count() }
    Surface(tonalElevation = 2.dp) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Ln $line, Col $column", style = MaterialTheme.typography.labelSmall)
            Text("$words words • ${text.length} chars • UTF-8 • ${fontSize.toInt()}sp", style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun FindReplaceBar(
    query: String,
    replace: String,
    replaceVisible: Boolean,
    matchCase: Boolean,
    onQuery: (String) -> Unit,
    onReplace: (String) -> Unit,
    onMatchCase: (Boolean) -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onReplaceOne: () -> Unit,
    onReplaceAll: () -> Unit,
    onClose: () -> Unit
) {
    Surface(tonalElevation = 4.dp) {
        Column(Modifier.fillMaxWidth().padding(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = query,
                    onValueChange = onQuery,
                    placeholder = { Text("Find") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(4.dp))
                TextButton(onClick = onPrev) { Text("↑") }
                TextButton(onClick = onNext) { Text("↓") }
                TextButton(onClick = onClose) { Text("×") }
            }
            if (replaceVisible) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = replace,
                        onValueChange = onReplace,
                        placeholder = { Text("Replace with") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = onReplaceOne) { Text("Replace") }
                    TextButton(onClick = onReplaceAll) { Text("All") }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = matchCase, onCheckedChange = onMatchCase)
                Text("Match case", style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@Composable
private fun SettingsDialog(viewModel: EditorViewModel) {
    val settings = viewModel.uiState.settings
    AlertDialog(
        onDismissRequest = { viewModel.showSettings(false) },
        title = { Text("Settings") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Theme", style = MaterialTheme.typography.titleSmall)
                ThemeMode.entries.forEach { mode ->
                    Row(
                        modifier = Modifier.fillMaxWidth().clickable { viewModel.setTheme(mode) }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = settings.themeMode == mode, onClick = { viewModel.setTheme(mode) })
                        Text(mode.name.lowercase().replaceFirstChar { it.uppercase() })
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 6.dp))
                SettingSwitch("Word Wrap", settings.wordWrap, viewModel::setWordWrap)
                SettingSwitch("Line Numbers", settings.lineNumbers, viewModel::setLineNumbers)
                SettingSwitch("Restore Session", settings.sessionRestore, viewModel::setSessionRestore)
                Spacer(Modifier.height(8.dp))
                Text("Font size: ${settings.fontSizeSp.toInt()} sp")
                Slider(
                    value = settings.fontSizeSp,
                    onValueChange = viewModel::setFontSize,
                    valueRange = 10f..32f,
                    steps = 21
                )
            }
        },
        confirmButton = { TextButton(onClick = { viewModel.showSettings(false) }) { Text("Done") } }
    )
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun RecentFilesDialog(viewModel: EditorViewModel) {
    val state = viewModel.uiState
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = { viewModel.showRecent(false) },
        title = { Text("Recent Files") },
        text = {
            if (state.recentFiles.isEmpty()) {
                Text("No recent files yet.")
            } else {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    state.recentFiles.forEach { file ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.showRecent(false)
                                    viewModel.openRecent(context, file.uri)
                                }
                                .padding(vertical = 10.dp)
                        ) {
                            Text(file.title, style = MaterialTheme.typography.bodyLarge)
                            Text(file.uri, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                        }
                        HorizontalDivider()
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { viewModel.showRecent(false) }) { Text("Close") } }
    )
}

private fun suggestedSaveName(title: String): String {
    val trimmed = title.trim().ifEmpty { "Untitled" }
    return if ('.' in trimmed) trimmed else "$trimmed.txt"
}
