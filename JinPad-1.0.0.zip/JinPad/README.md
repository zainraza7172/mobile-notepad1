# JinPad 1.0

JinPad is a fast, offline Android text and code editor inspired by the simplicity of classic desktop notepads while using its own branding and Android-native workflow.

## Core
- 100% offline: no login, no ads, no Internet permission
- New / Open / Save / Save As with Android Storage Access Framework
- Multiple tabs with unsaved indicators, long-press tab actions, move left/right, close others and safe close behavior
- Session restore / crash recovery and optional auto-save for saved files
- Recent files with pin/unpin and remove
- Open With and Share support

## Editing
- Undo / Redo, Select All, Cut / Copy / Paste
- Find / Replace / Replace All
- Match case, whole word and regular-expression search
- Go to Line
- Duplicate line
- Indent / Unindent and configurable tab width
- Word Wrap, line numbers, zoom and monospace editor
- Mobile keyboard coding toolbar
- Desktop keyboard shortcuts

## File formats
Designed for text-based files including TXT, Markdown, LOG, JSON, XML, CSV, HTML, CSS, JS, TS, Java, Kotlin, Python, C/C++, shell, SQL, YAML and more.

## Pro features
- Syntax highlighting for common code/config formats
- JSON and XML formatting
- Markdown preview; split editor/preview automatically on wide screens
- UTF-8, UTF-8 BOM, UTF-16 LE and UTF-16 BE read/write
- LF, CRLF and CR line ending conversion
- File properties with counts and estimated size
- Large-file protection that limits expensive highlighting/counting
- Light / Dark / System themes
- Professional desktop-style File / Edit / Format / View / Help menus

## Build
- Android compile/target SDK 36
- Minimum Android SDK 23
- JDK 17 bytecode target
- Kotlin/Compose project
- Package: `com.jin.notepad`
- Version: `1.0.0`

This project intentionally does not copy Microsoft trademarks, logos or branding. The product name and visual identity are JinPad.
